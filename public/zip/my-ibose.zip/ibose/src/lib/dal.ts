import 'server-only'
import { cookies, headers } from 'next/headers'
import { decrypt } from '@/lib/session'
import { cache } from 'react'
import { redirect } from 'next/navigation'
import modelStore from '@/models/store'
import modelUser from '@/models/modelUser'
import { connectDB } from './connectDB'
export const verifySession = (async () => {
  const cookie = (await cookies()).get('session')?.value
  const session = await decrypt(cookie)

  const head= (await headers())
  console.log("##############################################",session?.role)

  if (!session?.userId) {
    // redirect('/login')
  return { isAuth: true, userId: "699370619c9988f630e3e340" }
  }
 
  return { isAuth: true, userId: session?.userId,role:session?.role,isAdmin:session?.role==="admin" }
}) 


export async function getStoreAndProfile(){
  const session= await verifySession();
  await connectDB();
  console.log(session)
  // if(session?.role==="user")redirect('/')
  const store= await modelStore.findOne({ owner:session?.userId })
    .populate("owner", "name email avatar "); // تحدد الحقول التي تريدها فقط;
  if(!store)redirect('/')
  if(session?.role==="user")redirect('/')
  return {data:
    {
      name:store.name,
      description:store.description,
      phone:store.phone,
      address:store.address,
      slug:store.slug,
      logo:store.logo
    },
    user:{
      name:store?.owner?.name,
      email:store?.owner?.email,
      avatar:store?.owner?.avatar,
      role:store?.owner?.role
    }
  }
}
