"use client"

import * as React from "react"
import { Check, ChevronsUpDown, GalleryVerticalEnd } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,SidebarInput
  ,SidebarGroupContent ,SidebarGroup
} from "@/components/ui/sidebar"

export function TeamSwitcher({
  stores,
  defaultStore,
}: {
  stores:any
  defaultStore: any
}) {
  const [selectedVersion, setSelectedVersion] = React.useState(defaultStore)
console.log(Object.values(stores)[0]);
console.log(typeof stores);
  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger className="flex w-full " >
            <div className="gid flex flex-1 text-llkeft text-sm leading-tight">
                <span className="truncate font-medium">{selectedVersion.name}</span>
              </div>
                <span className="truncate text-xs">link:{selectedVersion.slug}</span>
              <ChevronsUpDown className="m-auto" />
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-(--radix-dropdown-menu-trigger-width)"
            align="start"
          >
            {stores.map((version) => (
              <DropdownMenuItem
                key={version.slug}
                onSelect={() => setSelectedVersion(version)}
              >
                v{version.slug}{" "}
                {version.slug === selectedVersion.slug && <Check className="ml-auto" />}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
              <SidebarGroup className="p">
                
        <SidebarGroupContent className="relative flex gap-2">
          
            <Avatar className="h-8 w-8 rounded-lg">
                <AvatarImage src={selectedVersion.imgUrl} alt={selectedVersion.name} />
                <AvatarFallback className="rounded-lg">CN</AvatarFallback>
              </Avatar>
              <SidebarInput
            id="search"
            placeholder=" بحث"
            className=""
          />
        </SidebarGroupContent>
              </SidebarGroup>
      </SidebarMenuItem>
    </SidebarMenu>
  )
}
