"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./index");
var user = { name: "Ibrahim", age: 22, city: "Sana'a" };
// حالة مفاتيح موجودة فقط
var filtered1 = (0, index_1.FDO)(user, ["name", "city"]);
console.log(filtered1);
// ناتج: { name: 'Ibrahim', city: "Sana'a" }
// حالة مفتاح غير موجود
var filtered2 = (0, index_1.FDO)(user, ["name", "email"]);
console.log(filtered2);
// ناتج: { name: 'Ibrahim' }  (email تم تجاهله)
var obj = { name: "Ibrahim" };
var desc = Object.getOwnPropertyDescriptor(obj, "name");
console.log(desc);
