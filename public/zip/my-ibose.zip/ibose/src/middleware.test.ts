import { NextRequest, NextResponse } from 'next/server'
// import { fallbackLng, languages } from '@/i18n/settings'

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  console.log(pathname,"pathname")
  // if (pathname === '/login' || pathname === '/signup') {
  //   return NextResponse.redirect(new URL(`/${fallbackLng}${pathname}`, req.url))
  // }

  // const hasLocale = languages.some(
  //   (l) => pathname === `/${l}` || pathname.startsWith(`/${l}/`)
  // )

  // if (!hasLocale) {
  //   return NextResponse.redirect(
  //     new URL(`/${fallbackLng}${pathname}`, req.url)
  //   )
  // }
}

export const config = {
  matcher: ['/((?!_next|api|favicon.ico).*)'],
}