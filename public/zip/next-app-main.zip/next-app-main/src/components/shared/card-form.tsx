'use client';
import React, { useState, forwardRef } from 'react';
import { IbovsCard } from '@/components/shared/ibovs-card'; // عدل المسار حسب مشروعك
import { Button } from '@/components/ui/button';
import { Method } from '@/lib/types';
import { useAlertApi } from '@/components/AlertProvider';
import { FieldGroup } from '../ui';

interface CardFormProps {
  api: { url: string; method: Method; action: string };
  title?: string;
  children: React.ReactNode;
  className?: string;
  onCancel?: () => void;
  onSuccess?: (data: any) => void;
  autoReset?: boolean; // هل يتم مسح الفورم بعد الإرسال؟
}

export const CardForm = forwardRef<HTMLDivElement, CardFormProps>(
  ({ children, api, title, className, onCancel, onSuccess, autoReset = true, ...props }, ref) => {
    const [message, setMessage] = useState('');
    const { alertApi } = useAlertApi();

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const body = Object.fromEntries(formData);

      try {
        const response = await alertApi(api.url, api.method, body, api);
        setMessage('');
        if (onSuccess) onSuccess(response);
        if (autoReset) e.currentTarget.reset();
      } catch (err: any) {
        setMessage(err?.message || 'حدث خطأ أثناء الإرسال');
      }
    };

    const handleCancel = () => {
      if (onCancel) onCancel();
      setMessage('');
    };

    return (
      <IbovsCard
        ref={ref}
        title={title ?? 'نموذج'}
        description="قم بتعبئة الحقول واضغط على حفظ"
        className={className}
        footer={
          <>
            <Button variant="outline" size='lg' type="button" onClick={handleCancel} className="col-span-3">
              Cancel
            </Button>
            <Button type="submit" form="CardForm" className="col-span-4">
              Submit
            </Button>
          </>
        }
        {...props}
      >
        <form id="CardForm" name="CardForm" onSubmit={handleSubmit} className="py-4">
          <input type="text" name="action" hidden defaultValue={api.action} />
          <FieldGroup>
          {children}
          </FieldGroup>
          {message && <span className="text-red-500">{message}</span>}
        </form>
      </IbovsCard>
    );
  }
);

CardForm.displayName = 'CardForm';
