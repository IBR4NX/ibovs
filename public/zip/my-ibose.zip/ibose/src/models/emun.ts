
 export enum StatusEnum{
  active="active",
  pending="pending",
  suspended="suspended",
  banned="banned"
}
export const Status=["active","pending","suspended","banned" ]
export const Role =["user", "store", "customer", "admin"]