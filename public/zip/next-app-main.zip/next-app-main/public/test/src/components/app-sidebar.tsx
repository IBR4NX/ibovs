"use client"

import * as React from "react"
import {
  AudioWaveform,
  BookOpen,
  Bot,
  Command,
  Frame,
  GalleryVerticalEnd,
  Map,
  PieChart,
  Settings2,
  SquareTerminal,
} from "lucide-react"

import { NavMain } from "@/components/nav/nav-main"
import { NavProjects } from "@/components/nav/nav-projects"
import  {NavUser }  from "@/components/nav/nav-user"
import  {NavStore}  from "@/components/nav/nav-store"
import { TeamSwitcher } from "@/components/nav/nav-switcher"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarRail,
} from "@/components/ui/sidebar"
import { useEffect } from "react"
import {
  Store,
  Package,
  ShoppingCart,
  Users,
  MapPin,
  Bell,
  Settings,
  BarChart3,
} from "lucide-react";

export const navMain = [
  {
    title: "لوحة التحكم",
    url: "/dashboard",
    icon: BarChart3,
    isActive: true,
    items: [
      {
        title: "نظرة عامة",
        url: "/dashboard",
      },
      {
        title: "الإحصائيات",
        url: "/dashboard/analytics",
      },
    ],
  },
  {
    title: "متجري",
    url: "/store",
    icon: Store,
    items: [
      {
        title: "عرض المتجر",
        url: "/store/view",
      },
      {
        title: "تخصيص المتجر",
        url: "/store/customize",
      },
    ],
  },
  {
    title: "المنتجات",
    url: "/products",
    icon: Package,
    items: [
      {
        title: "كل المنتجات",
        url: "/products",
      },
      {
        title: "إضافة منتج",
        url: "/products/new",
      },
    ],
  },
  {
    title: "الطلبات",
    url: "/orders",
    icon: ShoppingCart,
    items: [
      {
        title: "الطلبات الجديدة",
        url: "/orders?status=new",
      },
      {
        title: "الطلبات المكتملة",
        url: "/orders?status=completed",
      },
    ],
  },
  {
    title: "العملاء",
    url: "/customers",
    icon: Users,
    items: [
      {
        title: "قائمة العملاء",
        url: "/customers",
      },
    ],
  },
  {
    title: "الظهور الجغرافي",
    url: "/location",
    icon: MapPin,
    items: [
      {
        title: "إعداد الموقع",
        url: "/location",
      },
    ],
  },
  {
    title: "الإشعارات",
    url: "/notifications",
    icon: Bell,
    items: [
      {
        title: "كل الإشعارات",
        url: "/notifications",
      },
    ],
  },
  {
    title: "الإعدادات",
    url: "/settings",
    icon: Settings,
    items: [
      {
        title: "معلومات الحساب",
        url: "/settings/profile",
      },
      {
        title: "الأمان",
        url: "/settings/security",
      },
    ],
  },
];
// This is sample data.
const storeData={
     name:"",
     description:"",
     phone:"",
     address:"",
     slug:"",
   logo:""
}
const data = {
  user: {
    name: ".....",
    email: "....@..",
    avatar: "",
  },
  teams: [
    {
      name: "Ibrahim Al-Mekhlafi",
      logo: GalleryVerticalEnd,
      plan: "Enterprise",
    },
    {
      name: "Acme Corp.",
      logo: AudioWaveform,
      plan: "Startup",
    },
    {
      name: "Evil Corp.",
      logo: Command,
      plan: "Free",
    },
  ],
 
  projects: [
    {
      name: "Design Engineering",
      url: "#",
      icon: Frame,
    },
    {
      name: "Sales & Marketing",
      url: "#",
      icon: PieChart,
    },
    {
      name: "Travel",
      url: "#",
      icon: Map,
    },
  ],
}
import { myProfile } from "@/app/action/profile";
// import { SidebarOptInForm } from "./nav/sidebar-opt-in-form"
import { Separator } from "./ui"
import { SearchForm } from "./custom/search-form"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { getStore } from "@/controllers/store.controller"
export default function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const [user ,setUser]=React.useState(data.user);
  const [store ,setStore]=React.useState(storeData);
  const [loading ,setLoading]=React.useState(true);
  useEffect(() => {
    const user = async()=>{
     const data= await getStore()
     console.log("ssssssssssd");
     if(!data)return
      setStore(data.store);
      setUser(data.owner);
      localStorage.setItem("store", JSON.stringify(data.store));
      localStorage.setItem("user", JSON.stringify(data.owner));
    setLoading(false)
    }
    user();
  }, [0])
  if(loading)return null
  

  return (
    <Sidebar dir="rtl" side="right"  collapsible="icon" {...props}>
      <SidebarHeader>
        <NavStore store={store} /> 
        {/* <NavUser user={store} /> */}
      </SidebarHeader>
        <Separator orientation="horizontal" />
      <SidebarContent>
        <NavMain items={navMain} />
        <NavProjects projects={data.projects} />
      </SidebarContent>
      <SidebarFooter>
        <Separator/>
        {/* <SidebarOptInForm/> */}
        <NavUser user={user} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
