function sum(a, b) {
  return a + b;
}
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
// filter data object
function FDO(data, keysToKeep) {
  const filtered = Object.fromEntries(
    Object.entries(data).filter(([key]) => keysToKeep.includes(key))
  );
  return filtered;
}
module.exports = { sum ,capitalize,FDO};