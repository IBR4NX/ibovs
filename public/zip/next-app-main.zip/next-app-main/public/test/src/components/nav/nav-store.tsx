"use client";
import {
  BadgeCheck,
  Bell,
  ChevronsUpDown,
  CreditCard,
  LogOut,
  PenIcon,
  Sparkles,
} from "lucide-react";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "../ui";
import EditProfile from "../../ui/edit-user-form";
import { logout } from "@/controllers/user.controller";
import ImageForm from "@/ui/image-form";
import { useEffect ,useState} from "react"
import { getAllStores,getStore } from "@/controllers/store.controller"
export function NavStore({store}) {
  const { isMobile } = useSidebar();
  //const [store, setStore] = useState()
  const [stores, setStores] = useState()
  useEffect(() => {
    const user = async()=>{
    const data= await getAllStores()
    console.log(data);
     if(!data)return
      setStores(data.stores);
      //setStore(data.store);
      console.log(typeof data.stores);
    console.log(stores);
    }
    user();
  
  }, [0])
  if(!store)return null
  console.log(store);
  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              size="lg"
              className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            >
              <Avatar className="h-8 w-8 rounded-lg">
                <AvatarImage src={store.imgUrl} alt={store.name} />
                <AvatarFallback className="rounded-lg">CN</AvatarFallback>
              </Avatar>
              <div className="grid flex-1 text-llkeft text-sm leading-tight">
                <span className="truncate font-medium">{store.name}</span>
                <span className="truncate text-xs">{store.slug}</span>
              </div>
              <ChevronsUpDown className="ml-auto size-4" />
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-(--radix-dropdown-menu-trigger-width) min-w-56 rounded-lg"
            side={isMobile ? "bottom" : "right"}
            align="end"
            sideOffset={4}
          >
            <DropdownMenuLabel className="p-0 font-normal">
              <div className="flex items-center gap-2 px-1 py-1.5 text-sm">
                <Avatar className="h-8 w-8 rounded-lg">
                  <AvatarImage src={store.imgUrl} alt={store.name} />
                  <AvatarFallback className="rounded-lg">CN</AvatarFallback>
                </Avatar>
                <div className="grid flex-1 text-sm leading-tight">
                  <span className="truncate font-medium">{store.name}</span>
                  <span className="truncate text-xs">{store.slug}</span>
                </div>
                <EditProfile user={store}>
                  <PenIcon size={15} />
                </EditProfile>
                {/* <Button></Button> */}
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem>
                <Sparkles />
                Upgrade to Pro
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              
              {stores&&
                stores.map((s)=>(
              <DropdownMenuItem key={s._id}>
                {s.slug!==store.slug?
               <>
              <Avatar className="h-8 w-8 rounded-lg">
                  <AvatarImage src={s.imgUrl} alt={s.name} />
                  <AvatarFallback className="rounded-lg">CN</AvatarFallback>
                </Avatar>
                 <div className="grid flex-1 text-sm leading-tight">
                  <span className="truncate font-medium">{s.name}</span>
                  <span className="truncate text-xs">{s.slug}</span>
                </div>
               </> 
                 : <span>end</span> 
                }
              </DropdownMenuItem>
                ))
              }
                
              <DropdownMenuItem>
                <Bell />
                Notifications
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
export default NavStore