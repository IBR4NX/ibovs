# ibose

![npm](https://img.shields.io/npm/v/ibose?color=blue&label=version)
![node](https://img.shields.io/node/v/ibose?color=green&label=node)
![downloads](https://img.shields.io/npm/dt/ibose?color=orange&label=downloads)

مكتبة بسيطة لإجراء العمليات الرياضية، مكتوبة بـ JavaScript ومدعومة TypeScript.  

---

## التثبيت

```bash
npm install ibose 