"use server";
import { NextRequest, NextResponse } from "next/server";
import { colors } from "@/utils/colors";
import { getAuthCookies, verifyToken, checkRefresh } from "@/lib/auth";
const publicRoutes = ["/login", "/signup", "/register"];
const protectedRoutes = ["/dashboard","/account"];

export default async function proxy(req: NextRequest) {
	const now = new Date();
	console.log(`\n`, now, colors.bgBlue(" ").repeat(0), colors.bold(" proxy is start"));
	// 2. Check if the current route is protected or public
	const path = req.nextUrl.pathname;
	const parts = path.split("/").filter(Boolean); //
	const isProtectedRoute = protectedRoutes.includes(path);
	const isPublicRoute = publicRoutes.includes(path);
	const cookieStore = await getAuthCookies();
	const { token, refresh } = cookieStore;
	if (path.startsWith("/api")) {
		if(req.method!=="GET")console.log(colors.yellow(`》>> ¤${req.method} : `),colors.green(path), " >>>>> ");
		// console.log(req,cookieStore);
		// if(!token&&!refresh)return NextResponse.redirect(new URL("/login", req.nextUrl));
		return NextResponse.next();
	}
	//console.log(typeof token, typeof refresh);
	if (!token && refresh) {
		const successful = await checkRefresh(refresh);
		if (!successful) return NextResponse.redirect(new URL("/login", req.nextUrl));
		return NextResponse.redirect(new URL(path, req.nextUrl));
	}
	const auth = await verifyToken(token, "access");
	// 3. Decrypt the session from the cookie
	console.log("test: ",auth);
	// console.log(colors.strike(`${path}-${isProtectedRoute}-${isPublicRoute}:`),colors.blink(req.nextUrl.pathname));
	if (isPublicRoute) {
		console.log(`\x1b[1;34m➜`, "isPublicRoute", `\x1b[0m`);
		if (path.startsWith(publicRoutes[2])) {
			if (auth) return NextResponse.next();
			return NextResponse.redirect(new URL("/login", req.nextUrl));
		}
		if (!auth) return NextResponse.next();
		if (auth?.id) {
			console.log(`\n\x1b[1;32m➜`, auth?.id, `\x1b[0m`, " is: ", auth.role);
			return NextResponse.redirect(new URL("/", req.nextUrl));
		}
	}

	// 4. Redirect to /login if the user is not authenticated
	if (isProtectedRoute) {
		console.log(`\n\x1b[1;35m➜`, "isProtectedRoute", `\x1b[0m`);
		if (!auth?.id) {
			return NextResponse.redirect(new URL("/login", req.nextUrl));
		}
		if (!auth?.storeId && path.startsWith("/dashboard")){
			return NextResponse.redirect(new URL("/register", req.nextUrl));
		}
		return NextResponse.next();
	}
	// 5. Redirect to /dashboard if the user is authenticated

	console.log();
	console.log(colors.bgBlue(" ").repeat(10), colors.bold(" endd "), path, new Date().toLocaleTimeString());
	return NextResponse.next();
}

// Routes Proxy should not run on '/:path*',
export const config = {
	// matcher: ['/((?!api|_next/static|_next/image|.*\\.png$|favicons/).*)'],
	matcher: [
		"/dashboard/:path*",
		"/profile/:path*",
		"/login/:path*",
		"/signup/:path*",
		"/register/:path*",
		"/action",
		"/api/:path*",
		"/account/:path*",
		"/"
	]
};