import CreateStoreForm from '@/ui/createStore-form'
import React from 'react'

const Page = () => {
  return (
    <div className="max-w-xl">
    <CreateStoreForm/>
    </div>
  )
}

export default Page
