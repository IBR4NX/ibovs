'use client'
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis
} from "@/components/ui/breadcrumb";
import { usePathname } from "next/navigation";
function BreadcrumbAhmed() {
  const pathName = usePathname();
  const location =  (""+pathName).split('/');
  let pName="";
  let lastItems=location.length-1;
  return (
    <>
      <Breadcrumb>
        <BreadcrumbList>
        {/* <BreadcrumbEllipsis/> */}
        {location.map((item,i)=>{
          pName+="/"+item;
          // console.log(pName);
           return i===location.length-1?(
             <BreadcrumbItem key={item}>
                <BreadcrumbPage>{item}</BreadcrumbPage>
              </BreadcrumbItem> 
            ):(

              <BreadcrumbItem key={item} className="hidden md:block">
              <BreadcrumbLink href={pName} >{item}</BreadcrumbLink>
              </BreadcrumbItem>
            )
          }
        )
      }
      {/* <BreadcrumbSeparator className="hidden md:block" /> */}
        
        </BreadcrumbList>
      </Breadcrumb>
    </>
  );
}

export default BreadcrumbAhmed;
