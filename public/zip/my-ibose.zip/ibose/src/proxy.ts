'use server'
import { NextRequest, NextResponse } from 'next/server'
import { verifySession } from './lib/dal'
// 1. Specify protected and public routes
const protectedRoutes = ['/dashboard']
const publicRoutes = ['/login', '/signup', '/']

export default async function proxy(req: NextRequest) {
  // 2. Check if the current route is protected or public
  const path = req.nextUrl.pathname
  const isProtectedRoute = protectedRoutes.includes(path)
  const isPublicRoute = publicRoutes.includes(path)
  
  // 3. Decrypt the session from the cookie
  const session = await verifySession();
  console.log(`\n\x1b[1;32m➜`,session.userId,`\x1b[0m`," is: ",session.role)
  // console.log(session)
  // 4. Redirect to /login if the user is not authenticated
  if (isProtectedRoute && !session?.userId) {
    return NextResponse.redirect(new URL('/login', req.nextUrl))
  }

  // 5. Redirect to /dashboard if the user is authenticated
  if (
    isPublicRoute &&
    session?.userId &&
    !req.nextUrl.pathname.startsWith('/dashboard')
    && session?.userId !== "699370619c9988f630e3e340"
  ) {
    console.log("redirected /dashboard")
    // return NextResponse.redirect(new URL('/dashboard', req.nextUrl))
  }

  return NextResponse.next()
}

// Routes Proxy should not run on
export const config = {
  // matcher: ['/((?!api|_next/static|_next/image|.*\\.png$|favicons/).*)'],
  matcher: [
    // '/dashboard/:path*',
    '/profile/:path*',
    '/login/:path*',
    '/signup/:path*',
  ],
}