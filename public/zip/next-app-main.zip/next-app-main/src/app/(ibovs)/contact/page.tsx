import { CardForm } from '@/components/shared/card-form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export default function ContactUs() {
  return (
    <CardForm
      api={{ url: '/api/contact', method: 'POST', action: 'contact' }}
      title="تواصل معنا"
      //onSuccess={(data) => console.log('تم الإرسال:', data)}
      //onCancel={() => console.log('تم الإلغاء')}
    >
      <Input type="email" name="email" placeholder="بريدك الإلكتروني" required />
      <Textarea name="message" placeholder="رسالتك" required />
    </CardForm>
  );
}