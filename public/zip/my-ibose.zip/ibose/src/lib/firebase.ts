// Import the functions you need from the SDKs you need
import { getApps, initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
import { getStorage } from "firebase/storage"

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAtmIX5AQfqcdPO-gOEkUQJm51llQhcrZE",
  authDomain: "naqra-app.firebaseapp.com",
  projectId: "naqra-app",
  storageBucket: "naqra-app.appspot.com",
  messagingSenderId: "625210461180",
  appId: "1:625210461180:web:1395fbb7bf77181a998079",
  measurementId: "G-TNN6W537M8"
};

// storageBucket: "naqra-app.firebasestorage.app",
// Initialize Firebase
const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
console.log(getApps().length)
// const appS = !getApps().length
//   ? initializeApp(firebaseConfig)
//   : getApps()[0]

// Initialize Firebase
const storage = getStorage(app);
export {app, storage}