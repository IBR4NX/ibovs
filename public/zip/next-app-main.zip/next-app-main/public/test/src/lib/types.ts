export interface JWTPayload {
    id:string
    expiresAt?: Date
    role?: string
    slug?:string
  }
    name?: string
    email?: string
    iat?: number
    exp?: number
  
  export interface JWTUser {
    id: string
    role:string
    expiresAt?: Date
    iat?: number
    exp?: number
}
export interface JWTStore {
    id: string
    slug:string
    expiresAt?: Date
 
}
export interface userType {
    _id: string
    id?: string
    role: string
    name?: string
    email?: string
    imgUrl?:string
    expiresAt?: Date
  }

export interface storeType{
  _id: string
  id?: string
  slug: string
  name?: string
  imgUrl?:string
  expiresAt?: Date
}