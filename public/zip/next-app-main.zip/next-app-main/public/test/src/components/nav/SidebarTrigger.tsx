'use client'
import { Button } from "../ui";
import { Menu } from "lucide-react";
import { useSidebar } from "../ui/sidebar";

const SidebarTrigger = () => {
  const { setOpen,toggleSidebar } = useSidebar();

  return (
    <>
      <Button variant="ghost" size="icon" onClick={toggleSidebar}
      className="p-1">
        <Menu size={50} className="size-6" />
      </Button>
    </>
  );
};

export default SidebarTrigger;
