// "use client";
import React, { cache, use } from "react";
import { SidebarMenuItem } from "@/components/ui/sidebar";
import NavUser from "@/components/custom/nav-user";
import { myProfile } from "@/app/action/profile";
const my = await myProfile();
// import { useEffect } from "react";
const page = async () => {
  myProfile();
  const data = cache(() => {
    return {
      name: "ابراهيم دبوان  ",
      email: "admin@gmail.com",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    };
  });
  // if(!user)return

  return (
    <div className="">
      <SidebarMenuItem>
        <NavUser user={my} />
      </SidebarMenuItem>
    </div>
  );
};

export default page;
