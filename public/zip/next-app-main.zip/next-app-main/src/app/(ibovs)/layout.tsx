"use client"; // Client Component لأننا نستخدم SWR
import { useState, useEffect } from "react";
import { AlertProvider } from "@/components/AlertProvider";
export default function AccountLayout({
  children
}: {
  children?: React.ReactNode;
}) {
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setLoading(true);
    console.log("setLoading stop");
  }, []);
  console.log("render");
  if (!loading) return null;
  console.log("after loading");
  return (
    <>
      <AlertProvider>{children}</AlertProvider>
      
    </>
  );
}
