import { AppSidebar } from "@/components/custom/app-sidebar";
import React from "react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import { SearchForm } from "@/components/custom/search-form";
import {
  GalleryVerticalEnd,
  PanelsTopLeft,
  ChevronDown,
  Plus,
  Store,
  LayoutDashboard,
  Contact,
  Building,
  HandFist,
  Badge,
} from "lucide-react";

import Link from "next/link";
const data = [
  { name: "المتجر الإلكتروني", href: "/", Store },
  { name: "لوحة التحكم", href: "/dashboard", LayoutDashboard },
  { name: "بحث", href: "/#" },
  { name: "الخدمات", href: "#" },
  { name: "الملف الشخصي", href: "/#" },
  { name: "الإعدادات", href: "/#" },
];
const terms = [
  { name: "اتصل بنا", href: "/contact", icon: Contact },
  { name: "من نحن", href: "/about", icon: Building },
  { name: "الدعم الفني", href: "/support", icon: HandFist },
  { name: "المساعدة ", href: "/help", icon: Badge },
];

const SidebarPage = () => {

  return (
    <>
      <SidebarGroup>
        <SidebarMenu>
          {data.map((item) => (
            <SidebarMenuButton key={item.name}>
              <Link href={item.href}>{item.name}</Link>
            </SidebarMenuButton>
          ))}
        </SidebarMenu>
      </SidebarGroup>

      <SidebarGroup>
        <SidebarMenu>
          <SidebarGroupLabel> أخر</SidebarGroupLabel>
          {terms.map((item) => (
            <SidebarMenuButton key={item.name}>
              <item.icon />
              <Link href={item.href}>{item.name}</Link>
            </SidebarMenuButton>
          ))}
        </SidebarMenu>
      </SidebarGroup>
    </>
  );
};

export default SidebarPage;
