"use client";
import {
  BadgeCheck,
  Bell,
  ChevronsUpDown,
  CreditCard,
  LogOut,
  PenIcon,
  Sparkles,
} from "lucide-react";

import { Avatar, AvatarFallback, AvatarImage,AvatarBadge } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "../ui";
import EditProfile from "../../ui/edit-user-form";
import { logout } from "@/controllers/user.controller";
import ImageForm from "@/ui/image-form";
import { useEffect } from "react"
import { DynamicIcon } from 'lucide-react/dynamic';
import useSWR, { SWRConfig } from "swr";
interface objectUser{
    name: string;
    email: string;
    imgUrl: string;
    id?:string
  };
export function NavUser({user}) {
  const { isMobile } = useSidebar();
  //const { data:user} = useSWR("/user");
  if (!user) return <SidebarMenu>
    <SidebarMenuItem></SidebarMenuItem>
  </SidebarMenu>
  // console.log("begin data");
  // console.log(user.name);
  // console.log("end data");
  
  return (
    <SidebarMenu className=" " >
      <SidebarMenuItem className=" " >
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              size="lg"
              className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            >
              <Avatar className="h-8 w-8 rounded-lg">
                <AvatarImage src={user?.imgUrl} alt={user.name} />
                <AvatarFallback className="rounded-lg">CN</AvatarFallback>
                <AvatarBadge className="bg-green-600 dark:bg-green-800" />
              </Avatar>
              <div className="grid flex-1 text-llkeft text-sm leading-tight">
                <span className="truncate font-medium">{user.name}</span>
                <span className="truncate text-xs">{user.email}</span>
              </div>
              <ChevronsUpDown className="ml-auto size-4" />
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-(--radix-dropdown-menu-trigger-width) min-w-56 rounded-lg"
            side={isMobile ? "bottom" : "right"}
            align="end"
            sideOffset={4}
          >
            <DropdownMenuLabel className="p-0 font-normal">
              <div className="flex items-center gap-2 px-1 py-1.5 text-sm">
 
                <Avatar className="size-12 rounded-lg">
                  <AvatarImage src={user.imgUrl} alt={user.name} />
                  <AvatarFallback className="rounded-lg">CN</AvatarFallback>
                  <AvatarBadge className="bg-red-00 -mb-g1 -myl-1 text-white ring-0 size-4!" >
                    
                    <PenIcon size={16} className=" size-8! ring-0 " />
                  </AvatarBadge>
                </Avatar>
              
                <div className="grid flex-1 text-sm leading-tight">
                  <span className="truncate font-medium">{user.name}</span>
                  <span className="truncate text-xs">{user.email}</span>
                </div>
                
                <DynamicIcon name="image-plus" size={24} />
                <EditProfile user={user}>
                <DynamicIcon name="user-pen" size={24} />

                </EditProfile>
                {/* <Button></Button> */}
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem>
                <Sparkles />
                Upgrade to Pro
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem>
                <BadgeCheck />
                Account
              </DropdownMenuItem>
              <DropdownMenuItem>
                <CreditCard />
                Billing
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Bell />
                Notifications
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive" onClick={logout}>
              <LogOut />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
