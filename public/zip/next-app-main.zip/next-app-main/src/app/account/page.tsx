"use client";

import { useEffect, useId, useState, useMemo } from "react";
import CardInfo from "@/ui/cardInfo";
type User = {
	name: string;
	email: string;
	imgUrl?: string;
	role?: string;
};
import { TextInput } from "@/components/inputs";
import convertData from "@/services/convertData";
import useSWR, { useSWRConfig } from "swr";
import { DialogProvider } from "@/ui/dialogProvider";
export default function AccountPage() {
	const { data: user } = useSWR("/user");
	const con = useSWRConfig();
	const now = new Date()
	const data = useMemo(() => {
		    console.log("calculate");
				    return convertData(user);
						  }, [user]);
	console.log("uuid: ",now)
	console.log(now.toString())

	return (
		<DialogProvider>
		<div className='max-w-2xl mx-auto py-10 px-4'>
			{user ? (
				<CardInfo data={data} url='/user' />
			) : (
				<p className='text-muted-foreground'>No user data found.</p>
			)}
		</div>
		</DialogProvider>
	);
}