'use server'
import 'server-only'
import  {  StoreModel, IStore} from "@/models/store.model";
import { connectDB } from "@/lib/connectDB";
import mongoose, {Types} from 'mongoose';
export async function findStoreByOwner(owner:string) {
  await connectDB()
  return await StoreModel.find({ owner:owner.toString()}).populate('owner');
}
async function findStoreById(id:string) {
  await connectDB()
  const store= await StoreModel.findById(id).populate('owner');
  return store
}
async function  findStoreBySlug(slug:string) {
  await connectDB()
  return await StoreModel.findOne({ slug });
 // const {name ,owner,location,description,...rest}= await StoreModel.findById(store._id);
}
async function updateStore(id:string,data:object) {
  await connectDB()
  return await StoreModel.findByIdAndUpdate(id,data);
}

//    create store by owner
  //const test =await store.collection.dropIndex("owner_1");

export async function createStoreByOwner(data:IStore) {
  await connectDB()
  //await StoreModel.deleteMany({});
  const store= new StoreModel(data);
  const error =  store.validateSync();
  if(error){
    return {error} 
  }
  const slug = data.slug.toLowerCase().trim();
  const slugExists = await StoreModel.exists({ slug });
  if (slugExists) {
    throw new Error('Slug already exists plase modfiy slug ');
    }
  const storesCount = await StoreModel.countDocuments({ owner: data.owner });
  if (storesCount>=3) {
    throw new Error('Owner can only create up to 3 stores');
    }
   await store.save();
   return {success: true,message: "Store created successfully",store:store} 
  }


export async function deleteStoreByOwner(ownerId: string) {
  if (!Types.ObjectId.isValid(ownerId) ) {
    throw new Error("Invalid ownerId or storeId");
  }

  // البحث عن المتجر الذي يملكه owner
  const store = await StoreModel.findOne({ owner: ownerId });
  if (!store) {
    throw new Error("Store not found or you are not the owner");
  }

  // حذف نهائي
  // return await StoreModel.findByIdAndDelete(storeId);
}