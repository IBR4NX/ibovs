
import mongoose, {Types, Document} from 'mongoose';
//    Name
export interface IStore extends Document {
  id?:string;
  _id: Types.ObjectId;
  owner: Types.ObjectId;
  slug: string;
  name?: string;
  description?: string;
  phone?: string;
  location?: {
    city: string;
    lat: number;
    lng: number;
  };
  imgUrl?: string;
  isActive?: boolean;
}
//    Name
const schema = new mongoose.Schema<IStore>(
  {
    owner: {type: Types.ObjectId,ref: "User",required: true},
    name: {type: String,trim: true,required: true,minlength: 3,maxlength: 100},
    slug: {type: String,required: true,unique: true,lowercase: true,trim: true
    },
    description: {type: String,maxlength: 500,
    },
    location: {
    type: { type: String, default: 'Point' },
    coordinates: { type: [Number], index: '2dsphere' } // [longitude, latitude]
  },
  analytics: {
    views: { type: Number, default: 0 },
    totalSales: { type: Number, default: 0 }
  },
  status: { 
    type: String, 
    enum: ['active', 'pending', 'suspended'], 
    default: 'pending' 
  },

    imgUrl: {type: String, default:'http://localhost:3000/favicons/favicon-96x96.png'},
    isActive: {type: Boolean,default: true},
  },
  {
  timestamps: true ,
  versionKey: false,
  }
);

schema.index({ _id: 1,owner: 1,slug: 1, isActive: 1 });
export const StoreModel = mongoose.models.Store || mongoose.model("Store", schema); // 3  4
// schema.pre(/^find/,function(this){
//   return this.
// })
export default { schema,model:StoreModel} 
