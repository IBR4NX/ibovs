import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2Icon } from "lucide-react";
import { uploadForm } from "@/utils/uploadForm";
interface Props {
  children: React.ReactNode;
  url: string;
  title?: string;
  description?: string;
}

const ImageForm = ({ children, url }: Props) => {
  const [imagePreview, setImagePreview] = React.useState<string | null>(null);
  const queryClient = useQueryClient();
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  const mutation = useMutation({
    mutationFn: uploadForm,
    onSuccess:()=>{
      queryClient.invalidateQueries({queryKey:["image"]})
    }
  })

  return (
    <>
      <Dialog>
        <DialogTrigger className=" p-2">{children}</DialogTrigger>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>رفع الصورة</DialogTitle>
            <DialogDescription>
              لرفع صورة جديدة اضغط على الصورة لاختيار صورة جديدة
            </DialogDescription>
          </DialogHeader>
          <form
            className="items-center px-10"
            onSubmit={(e) => {
              e.preventDefault();
              mutation.mutate({ url: url, e: e.currentTarget });
            }}
          >
            <Avatar className=" size-52 m-auto mb-5">
              <Label htmlFor="image">
                <AvatarImage src={imagePreview ?? undefined} />
              </Label>
              <Input
                type="file"
                accept="image/*"
                id="image"
                name="image"
                className=" absolute size-full opacity-0 text-wrap z-10 bg-red-500 rounded-full"
                onChange={handleImageChange}
              />
              <AvatarFallback>اضافة الصورة</AvatarFallback>
            </Avatar>
            <Button disabled={mutation.isPending} type="submit" className="w-full">
              {mutation.isPending && (
                <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
              )}
              رفع الصورة
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ImageForm;
