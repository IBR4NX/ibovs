import IbovsCard from "./ibovs-card"

export {
  IbovsCard,
}