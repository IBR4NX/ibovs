import { useState ,FormEvent } from "react"
import {IbovsCard} from "@/components/shared"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"

export default function ContactCard() {
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const data = {
      email,
      message
    }
    console.log(data)
  }
  return (
    <IbovsCard
      title="Contact Us"
      description="Send us a message"
      className="max-w-md"
      footer={
        <Button type="submit" form="contact-form">
          Send
        </Button>
      }
    >
      <form id="contact-form" onSubmit={handleSubmit} className="space-y-4">
        <Input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <Textarea
          placeholder="Your message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
        />
      </form>
    </IbovsCard>
  )
}