import { toast } from "sonner";

type ActionState = {
  success?: boolean;
  message?: string;
};

export default function actionToast(state?: ActionState,pending?:boolean) {
  console.log(state);
  if(!state&&!pending)return
  toast.promise(
   new Promise((resolve, reject) => {
    setTimeout(() => {
      if (state?.success) resolve(state?.message ?? "Success");
      else reject(state?.message ?? "Error");
    }, 1000);
   }),
    {
      loading: "Loading...",
      success: state?.message ?? "Success",
      error: state?.message ?? "Error",
      position: "top-center",
    },
  
  );
}

// import actionToast from "@/utils/action-toast";
// import { useEffect } from "react";
// useEffect(() => {
//   actionToast(state);
// }, [state]);