export default async function Page({
 params,
 }: {
 params: Promise < { slug: string } >
 }) {
 const { lang } = await params
 console.log(params.lang);
 return <div>
My Post: {lang}
 </div>
 }