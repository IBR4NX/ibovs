'use server'
import { NextRequest, NextResponse } from 'next/server';
import {findAllUsers, findUserByEmail ,
updateUserById, deleteUserById, toggleUserActiveById
} from "@/services/user.service"
// GET /api/users أو /api/users?email=test@example.com
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const email = url.searchParams.get('email');
  if (email) {
    // البحث بواسطة البريد الإلكتروني
    const user = await findUserByEmail(email);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    return NextResponse.json(user);
  }
  // جلب كل المستخدمين
  const users = await findAllUsers();
  return NextResponse.json(users);
}

// POST /api/users login and signup
import {  setAuthUser, setAuthRefresh } from '@/lib/auth';
import { setAuthCookies } from '@/lib/jwt'
import {login, signup } from '@/controllers/user.controller'
export async function POST(req: NextRequest) {
    const body = await req.json();
    const {action,name,email,password} = body;
    console.log(body);
    let message:"Login successful"|"Signup successful";
  try {
    if(body.action==="login") {
      const user = await login(email, password);
      await setAuthUser(user)
    //  await setAuthRefresh(user)
      message="Login successful"
      console.log(user);
    }
    else if (body.action==="signup") {
      console.log("to is here route 41");
      const user = await signup(name,email,password);
      await setAuthUser(user)
      message="Signup successful"
      console.log(user);
    }
    
    return NextResponse.json({ message:"Login successful" }, { status: 200 });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: "catch: "+error.message }, { status: 400 });
  }
  console.log("redirect")
//  return NextResponse.redirect(new URL('/', req.url));

}

// PUT /api/users/:id
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const updated = await updateUserById(params.id, await req.json());
  if (!updated) return NextResponse.json({ error: 'User not found' }, { status: 404 });
  return NextResponse.json(updated);
}

// DELETE /api/users/:id
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const deleted = await deleteUserById(params.id);
  if (!deleted) return NextResponse.json({ error: 'User not found' }, { status: 404 });
  return NextResponse.json(deleted);
}

// PATCH /api/users/:id/toggle
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await toggleUserActiveById(params.id);
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });
  return NextResponse.json({ message: `User is now ${user.isActive ? 'active' : 'inactive'}`, user });
}