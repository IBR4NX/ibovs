import { SearchForm } from "@/components/custom/search-form";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import { Plus } from "lucide-react";

interface TypeProps {
  children: React.ReactNode;
  userInfo: React.ReactNode;
}

function DashboardLayout({ children, userInfo }: TypeProps) {
  return (
    <>
      <Sidebar dir="rtl" side="right" variant="inset">
        <SidebarHeader>
          {/* <SidebarMenu> */}
          {/* </SidebarMenu> */}
            {userInfo}
        <SidebarMenu>
          <SearchForm />
        </SidebarMenu>
        </SidebarHeader>
        <SidebarContent>
          {children}
        </SidebarContent>
              <SidebarFooter>
               <SidebarGroup>
          <SidebarGroupLabel>Application</SidebarGroupLabel>
          <SidebarGroupAction>
            <Plus /> <span className="sr-only">Add Project</span>
          </SidebarGroupAction>
        </SidebarGroup>
      </SidebarFooter>
      </Sidebar>
    </>
  );
}
export default DashboardLayout;
