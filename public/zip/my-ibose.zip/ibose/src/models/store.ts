// 'use server'
import 'server-only'
import mongoose, { Schema, model, Types } from "mongoose";

interface StoreInter {
  owner: Types.ObjectId;
  name?: string;
  slug?: string;
  description?: string;
  phone?: string;
  location?: {
    city: string;
    lat: number;
    lng: number;
  };
  imgUrl?: string;
  isActive?: boolean;
  test():void; 
}

export const storeSchema = new Schema(
  {
    owner: {type: Types.ObjectId,ref: "User",required: true,unique: true, },
    name: {type: String,trim: true,minlength: 3,maxlength: 100},
    slug: {type: String,required: true,unique: true,lowercase: true,trim: true

    },
    description: {type: String,maxlength: 500,
    },
    phone: {type: String,required: true,trim: true,minlength: 8,maxlength: 15,
    },

    imgUrl: {type: String, // URL من Firebase
    },

    location: {
      city: String,
      lat: Number,
      lng: Number,
    },
    isActive: {type: Boolean,default: true,
    },
  },
  {
  timestamps: true ,
  versionKey: false,
  }
);

// Index للبحث بالرابط
storeSchema.index({ slug: 1 });
// storeSchema.index({ owner: 1 });
//  Store.findByOwner("699089b6b2765a3e35c52ce1")

const Store =mongoose.models.Store || model("Store",storeSchema) ;
//  const newStore=new Store({
//   name:"test",
//   owner:"699089b6b2765a3e35c52ce1",
//   slug:"test",
//   description:"test djkl lkdblksd ",
//   phone:"714339227",
//   logo:"test",
//   location:{
//     city:"test",
//     lat:0,
//     lng:0,
//   },

//  })
//  newStore.save();
// Store.find().findByOwner("699089b6b2765a3e35c52ce1")
Store.watch().on('response',()=>{
  console.log("response")
})
 export default Store


