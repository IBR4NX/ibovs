import SignUpForm from '@/ui/signup-form'
import React from 'react'

const Page = () => {
  return (
    <div>
      <SignUpForm/>
    </div>
  )
}

export default Page


 