
import { Loader2Icon } from 'lucide-react'
import Image from 'next/image'
function loading() {
  return (
    <div className=' flex relative justify-center items-center h-screen '>
      <div className="">
      <Loader2Icon className=' animate-spin absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2' />
      <Image src="/favicons/logo.png" alt="logo" width={100} height={100}
      className=' animate-in' />
      </div>
      
    </div>
  )
}

export default loading
