"use client";

import { useState } from "react";
import { EyeIcon, EyeOffIcon } from "lucide-react";
import { Field, FieldDescription, FieldLabel } from "@/components/ui/field";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@/components/ui/input-group";

type PasswordInputProps = {
  label?: string;
  name: string;
  placeholder?: string;
  description?: string;
  defaultValue?: string;
  value?: string;
  onChange?: (value: string) => void;
  className?: string;
};

export default function PasswordInput({
  label="password",
  name="password",
  placeholder="Enter password",
  description,
  defaultValue = "",
  value,
  onChange,
  className,
}: PasswordInputProps) {
  const [show, setShow] = useState(false);
  const [internalValue, setInternalValue] = useState(defaultValue);

  const isControlled = value !== undefined;
  const inputValue = isControlled ? value : internalValue;

  const handleChange = (val: string) => {
    if (!isControlled) setInternalValue(val);
    onChange?.(val);
  };

  return (
    <Field className={className}>
      {label && <FieldLabel htmlFor={name}>{label}</FieldLabel>}

      <InputGroup>
        <InputGroupInput
          id={name}
          name={name}
          type={show ? "text" : "password"}
          placeholder={placeholder}
          value={inputValue}
          onChange={(e) => handleChange(e.target.value)}
        />

        <InputGroupAddon
          align="inline-end"
          className="cursor-pointer"
          onClick={() => setShow((prev) => !prev)}
        >
          {show ? <EyeIcon size={18} /> : <EyeOffIcon size={18} />}
        </InputGroupAddon>
      </InputGroup>

      {description && (
        <FieldDescription>{description}</FieldDescription>
      )}
    </Field>
  );
}