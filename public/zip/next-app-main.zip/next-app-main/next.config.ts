import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  swcMinify: true, // تعطيل minify أثناء dev لتسريع rebuild
 webpack: (config, { dev }) => {
   if (dev) {
      // تسريع إعادة البناء
      config.cache = {
        type: "memory",
      };

      // تعطيل تحسينات ثقيلة أثناء التطوير
      config.optimization.minimize = false;
      config.optimization.splitChunks = false;
    } 
   return config;
 },
};

export default nextConfig;