
import mongoose, {Types, Document} from 'mongoose';
//    Name
export interface IStore extends Document {
  _id: Types.ObjectId;
  owner: Types.ObjectId;
  name?: string;
  slug?: string;
  description?: string;
  phone?: string;
  location?: {
    city: string;
    lat: number;
    lng: number;
  };
  imgUrl?: string;
  isActive?: boolean;
}
//    Name
const schema = new mongoose.Schema<IStore>(
  {
    owner: {type: Types.ObjectId,ref: "User",required: true, },
    name: {type: String,trim: true,required: true,minlength: 3,maxlength: 100},
    slug: {type: String,required: true,unique: true,lowercase: true,trim: true
    },
    description: {type: String,maxlength: 500,
    },
    phone: {type: String,trim: true,minlength: 8,maxlength: 15,
    },
    location: {
      city: String,
      lat: Number,
      lng: Number,
    },
    imgUrl: {type: String, default:'/favicons/favicon.ico'},
    isActive: {type: Boolean,default: true},
  },
  {
  timestamps: true ,
  versionKey: false,
  }
);

schema.index({ _id: 1,owner: 1,slug: 1, isActive: 1 });
export const StoreModel = mongoose.models.Store || mongoose.model("Store", schema); // 3  4
// schema.pre(/^find/,function(this){
//   return this.
// })
export default { schema,model:StoreModel} 
