'use server'
// import 'server-only';
import { FormState } from '@/lib/definitions'
import { redirect } from 'next/navigation';
import modelUser from '@/models/modelUser';
import { connectDB } from "@/lib/connectDB";
import { verifySession } from '@/lib/dal';
import { supabase } from '@/lib/envConfig';
import { deleteSession } from '@/lib/session';
import { cache } from 'react'
import { revalidatePath } from 'next/cache';
export const myProfile = cache(async () => {
  const session = await verifySession();
  await connectDB();
  const data = await modelUser.findById(session?.userId)
  if (data) {
    const user = {
      name: data.name,
      email: data.email,
      avatar: data.avatar,
      id:data._id
    }
    console.log(data)
    return user
  } else {
    deleteSession()
    redirect('/login')
  }

})

export async function updateProfile(state: FormState, formData: FormData): Promise<FormState> {
  const session = await verifySession()

  // formData.forEach((value, key) => {
  //   console.log(key, value)
  // })
  const dataUser = {
    name: formData.get('name'),
    email: formData.get('email'),
    username: formData.get('username')
  }
  const avatar = formData.get('avatar') as File

  await connectDB();
  const userup = await modelUser.findByIdAndUpdate(session?.userId, dataUser)
  if (!userup) {
    return {
      success: false,
      message: "Failed to update user profile",
    }
  }
  redirect('/dashboard')

}
export async function updateAvatar(state: FormState, formData: FormData) {
  const session = await verifySession()
  const avatar = formData.get('avatar') as File
  console.log(avatar)
  if (avatar.size) {
    console.log("noooooooooo", avatar.name)
    const fileName = `${session?.userId}`;
    const { data: uploadData, error } = await supabase.storage
      .from("Ibovs")
      .upload(fileName, avatar, {
        cacheControl: '3600',
        upsert: true,
      });
    const { data } = supabase.storage
      .from("Ibovs")
      .getPublicUrl(fileName);
    await connectDB();
    const userup = await modelUser.findByIdAndUpdate(session?.userId, { avatar: data.publicUrl })
    if (!userup) {
      return {
        success: false,
        message: "Failed to update user profile",
      }
    }
    revalidatePath('/dashboard')
    redirect('/dashboard')
  }
}
