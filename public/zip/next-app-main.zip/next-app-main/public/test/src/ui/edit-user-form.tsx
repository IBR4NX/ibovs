"use client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import Form from "next/form";
import { Field, FieldGroup } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
interface EditProfilePorps {
  user?: { name: string; email: string; avatar?: string };
  children: React.ReactNode;
}
import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { updateAvatar, updateProfile } from "@/app/action/profile";
import { Spinner } from "../components/ui/spinner";

import { useActionState } from "react";
import ImageForm from "@/ui/image-form";
export function EditProfile({ children, user }: EditProfilePorps) {
  const [state, action, pending] = useActionState(updateProfile, undefined);
 const [stateAvatar, actionAvatar, pendingAvatar] = useActionState(updateAvatar, undefined);
  const [imagePreview, setImagePreview] = React.useState<string | null>(
    user?.avatar ?? null
  );
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      // actionAvatar();
    }
  };
  console.log(state, pending);
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // action(e.currentTarget);
    // console.log(e.currentTarget.avatar.value);
  };

  return (
    <Dialog>
      <DialogTrigger className=" p-2">{children}</DialogTrigger>
      <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>تعديل معلومات </DialogTitle>
            <DialogDescription>
              ادخل معلومات المستخدم هنا. اضغط على حفظ عند اتمام التعديلات.
            </DialogDescription>
          </DialogHeader>
            <Form action={actionAvatar} className="flex items-center px-10" >
               <ImageForm url="/api/user" title="تعديل أفتار المستخدم" >
            <Avatar className="w-32 h-32 m-auto">
              <Label htmlFor="avatar">
                <AvatarImage src={imagePreview ?? undefined} />
              </Label>
              <Input
                type="file"
                accept="image/*"
                id="avatar"
                name="avatar"
                className=" absolute size-full opacity-0 text-wrap z-10 bg-red-500 rounded-full"
                onChange={handleImageChange}
                />
              <AvatarFallback>اضافة الصورة</AvatarFallback>
            </Avatar>
            </ImageForm> 
              <Button type="submit" > حفظ الصورة
              </Button>
                </Form>
             <Form action={action} onSubmit={handleSubmit} id="form">
            <FieldGroup>
            <Field>
              <Label htmlFor="name">الاسم</Label>
              <Input id="name" name="name" defaultValue={user?.name} />
            </Field>
            <Field>
              <Label htmlFor="email">البريد الالكتروني</Label>
              <Input id="email" name="email" defaultValue={user?.email} />
            </Field>
          </FieldGroup>
          <DialogFooter className="mt-4">
            {state?.message && <p className="text-red-500">{state?.message}</p>}
            <DialogClose asChild>
              <Button variant="outline">إلغاء</Button>
            </DialogClose>
            <Button
              // type="submit"
              disabled={pending}
              form="form"
            >
              {pending && <Spinner />}
              حفظ التعديلات
            </Button>
          </DialogFooter>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
export default EditProfile;
