import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
};

export const i18n = {defaultLocale: 'ar',locales: ['en', 'ar']}
export default nextConfig;