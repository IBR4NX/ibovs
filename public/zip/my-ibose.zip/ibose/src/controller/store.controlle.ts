'use server'
import 'server-only'
import  {  StoreModel, IStore} from "@/models/store.model";
import { connectDB } from "@/lib/connectDB";
import { Types } from 'mongoose';
import { redirect } from 'next/navigation';
import { createSessionStore } from '@/lib/session/create';
export async function findStoreByOwner(owner:any) {
  return await StoreModel.findOne({ owner:owner.toString() }).populate('owner');
}

async function findStoreById(id:string) {
  const {name ,owner,...rest}= await StoreModel.findById(id);
  return {name,owner,...rest}
}
async function  findStoreBySlug(slug:string) {
  const store= await StoreModel.findOne({ slug });
  const {name ,owner,location,description,...rest}= await StoreModel.findById(store._id);
  return {name,owner,...rest}
}
async function updateStore(id:string,data:object) {
  return await StoreModel.findByIdAndUpdate(id,data);
}

//    create store by owner
export async function createStoreByOwner(owner:any,data:object) {
  
  const store= new StoreModel({...data,owner:owner.toString()});
  const error =  store.validateSync();
  if(error){
    return {success: false,message: error} 
  }

  const findStore = await findStoreByOwner(owner);
  if (findStore) {
    const storeup = await updateStore(findStore._id,{...data,owner:owner.toString()});
      return {success: true,message: "Store updated successfully",store:storeup} 
      // return {success: false,message: "Store already exists"}
    }
   await store.save();
   return {success: true,message: "Store created successfully",store:store} 
  }
