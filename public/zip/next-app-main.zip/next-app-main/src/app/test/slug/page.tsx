"use client";
import React, { useEffect, useState } from "react";
function Page() {
  const [data, setData] = useState();

  useEffect(() => {
    
  }, []);
  return <div>{JSON.stringify(data)}</div>;
}

export default Page;
