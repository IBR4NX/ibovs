// "use client";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  useSidebar,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import {
  GalleryVerticalEnd,
  PanelsTopLeft,
  ChevronDown,
  Plus,
  Store,
  LayoutDashboard,
  Contact,
  Building,
  HandFist,
  Badge,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SearchForm } from "./search-form";

import Link from "next/link";
const data = [
  { name: "المتجر الإلكتروني", href: "/", Store },
  { name: "لوحة التحكم", href: "/dashboard", LayoutDashboard },
  { name: "بحث", href: "/#" },
  { name: "الخدمات", href: "#" },
  { name: "الملف الشخصي", href: "/#" },
  { name: "الإعدادات", href: "/#" },
];
const terms = [
  { name: "اتصل بنا", href: "/contact", icon: Contact },
  { name: "من نحن", href: "/about", icon: Building },
  { name: "الدعم الفني", href: "/support", icon: HandFist },
  { name: "المساعدة ", href: "/help", icon: Badge },
];

export async function AppSidebar() {
  // const { open, setOpen } = useSidebar();
  // const [user, setUser] = useState({name:"",email:"",phone:""})
  // const [loading, setLoading] = useState(true)
  // const path = usePathname();

  // const res= await axios.get("/profile/my")
  // if(!res)return
  // console.log(res)
  // localStorage.setItem("user",JSON.stringify(res?.data));
  // const user=res?.data
  // setLoading(false)
  // console.log(res?.data);
  const response = await fetch("https://jsonplaceholder.typicode.com/posts/1");
  const dataUser = await response.json();

  return (
    <Sidebar dir="rtl" side="right" variant="inset">
      {/* Header */}
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            {/* {loading? */}
            {/* <>
                   <LoaderSkeleton width={35} height={35} borderRadius={100} />
                    <div className="w-3/4">
                    <LoaderSkeleton className="m-1" width={100} height={15} borderRadius={8} />
                      <LoaderSkeleton height={15} />
                    </div>
                   </>
                  : */}
            {/* <NavUser user={{email:user.email,name:user.name}}/> */}
            {/* } */}
          </SidebarMenuItem>
        </SidebarMenu>
        <SidebarMenu>
          <SearchForm />
        </SidebarMenu>
      </SidebarHeader>
      {/* Content */}
      <SidebarContent>
        <SidebarGroup>
          <SidebarMenu>
            {data.map((item) => (
              <SidebarMenuButton key={item.name}>
                <Link href={item.href}>{item.name}</Link>
              </SidebarMenuButton>
            ))}
          </SidebarMenu>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarMenu>
            <SidebarGroupLabel> أخر</SidebarGroupLabel>
            {terms.map((item) => (
              <SidebarMenuButton key={item.name}>
                <item.icon />
                <Link href={item.href}>{item.name}</Link>
              </SidebarMenuButton>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      {/* Footer */}
      <SidebarFooter>
        <SidebarGroup>
          <SidebarGroupLabel>Application</SidebarGroupLabel>
          <SidebarGroupAction>
            <Plus /> <span className="sr-only">Add Project</span>
          </SidebarGroupAction>
        </SidebarGroup>
      </SidebarFooter>
    </Sidebar>
  );
}
