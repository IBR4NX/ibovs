"use client";
import {findAllStore} from '@/repositories/store.repository'
import React, { useEffect, useState } from "react";
function Page() {
  const [data, setData] = useState();

  useEffect(() => {
    
     findAllStore().then((result) => {
    console.log(result);
    setData(result)
     }).catch((error) => {
       console.error('Promise Catch:', error);
       
     })
  }, []);
  return <div>{JSON.stringify(data)}</div>;
}

export default Page;
