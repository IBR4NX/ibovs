import LoginForm from '@/ui/login-form'
import React from 'react'

const Page = () => {
  return (
    <>
    {/* <div className=" flex justify-center items-center h-screen w-screen">

    <div className=' max-w-xs w-sm' >
    </div>
    </div> */}
      <LoginForm/>
    </>
  )
}

export default Page
