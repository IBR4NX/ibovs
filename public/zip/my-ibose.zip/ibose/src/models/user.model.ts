
import mongoose, {Types, Document} from 'mongoose';
import { Status, Role } from './emun';
//    Name
export interface IUser extends Document {
  _id: Types.ObjectId;
  name?: string;
  email?: string;
  password?: string;
  role?: string;
  status?: string;
  imgUrl?: string;
  isActive?: boolean;
}
//    Name
const schema = new mongoose.Schema<IUser>(
  {   
    name: { type: String, required: [true," name is required"] },
    email: { type: String, required: [true," email is required"],
      match: [/^\S+@\S+\.\S+$/, "Invalid email address"],
      unique: true,lowercase: true,trim: true,
    },
    role: { type: String,select:true,enum:Role ,default: "user", 
    },
    isActive: {type: Boolean,default: true},
    status:{ type: String, emun: Status, default: "active"
    },
    password: { type: String, required: [true," password is required"],
      minLength: [6, "Password must be at least 6 characters long"],
    },
    imgUrl:{type: String,default:"/favicons/favicon.ico"
    },
    
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'createdAt' },
  }
);

schema.index({ _id: 1,email: 1, status: 1 });

export const userModel = mongoose.models.User || mongoose.model("User", schema); // 3  4
// export default { schema,model:userModel} 
export default userModel;
