"use server"
//import 'server-only'
import { SignJWT, jwtVerify } from 'jose'
import { SESSION_SECRET,JWT_REFRESH_SECRET } from '@/lib/envConfig'
import { cookies } from 'next/headers'
import {JWTUser ,JWTStore, JWTPayload} from './types'

const encodedKey = new TextEncoder().encode(SESSION_SECRET)
const encodedKeyRefresh = new TextEncoder().encode(JWT_REFRESH_SECRET)
async function getExpiresAt() {
 return await new Date(Date.now() + 60 * 60 * 1000)
}

export async function encrypt(payload: object) {
  console.log("encrypt:18 : ",payload);
  return await  new SignJWT({...payload})
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(encodedKey)
}
export async function encryptRefresh(payload: object) {
  return await  new SignJWT({...payload})
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(encodedKeyRefresh)
}

export async function decrypt(session: string | undefined = ''):Promise<JWTPayload> {
  try {
    const { payload } = await jwtVerify(session, encodedKey, { algorithms: ['HS256'], })
    console.log(" @/lib/auth :decrypt 25; ", payload.id);
    return payload as unknown as JWTPayload
  } catch (error) {
    // console.log('Failed to verify session',session)
    return null as any
    console.log("from @/lib/auth : decrypt 25",error);
  }
}
export async function verifyRefreshToken(name:string="refreshAuth"): Promise<JWTPayload | null> {
  try {
    const cookie = (await cookies()).get(name)?.value
    //const session = await decrypt(cookie)
    const verified = await jwtVerify(cookie, encodedKeyRefresh, { algorithms: ['HS256'], });
    const payload=verified.payload
    return payload as unknown as JWTPayload
  } catch (error) {
    return null as any
  }
}


export async function setCookie(name:string='auth',session:string,expiresAt:Date) {
  const cookie = await cookies()
  cookie.set(name, session, {
    httpOnly: true,
    secure: false,
    expires: expiresAt,
    sameSite: 'lax',
    path: '/',
  })
}
import {findStoreByOwner } from '@/repositories/store.repository'
import userModel, { IUser } from '@/models/user.model';
import { IStore } from '@/models/store.model'
export async function setAuthStore(data:IStore) {
  console.log(data);
  const filterData = {id: data.id ?? data._id.toString(),
  owner:data.owner.toString(), slug: data.slug};
  const expiresAt =await getExpiresAt()
  const session = await encrypt({ ...filterData, expiresAt })
  return await setCookie("storeAuth",session, expiresAt)
}
export async function setAuthUser(data:IUser) {
  const filterData = {id: data?.id ?? data._id.toString(), role: data.role};
  const expiresAt = await getExpiresAt()
  const session = await encrypt({...filterData, expiresAt })
  if(filterData.role==="seller"){
    const store= await findStoreByOwner(filterData.id)
    if(store) await setAuthStore(store)
  }
  return await setCookie("userAuth",session, expiresAt)
  
}
export async function setAuthRefresh(data:IUser) {
  const filterData = {id: data.id ?? data._id.toString(), role: data.role};
  const expiresAt = await getExpiresAt()
  const session = await encrypt({...filterData, expiresAt })
  if(filterData.role==="seller"){
    const store= await findStoreByOwner(filterData.id)
    filterData.store=store._id.toString()
    await setAuthStore(store)
  }
  const refresh = await encryptRefresh({id:filterData.id})
  await setCookie("refreshAuth",refresh, expiresAt)
  return await setAuthUser(data)
  
}
export async function verifyAuth(name:string="auth") {
  try {
  const cookie = (await cookies()).get(name)?.value
  const session = await decrypt(cookie)
  console.log("from lib auth verifyAuth:50")
  return session
   
  } catch (err) {
   console.error('Error:', err);
   
  }
}

export async function verifyAuthUser():Promise<JWTUser> {
 return await verifyAuth("userAuth") as unknown as JWTUser
}
export async function verifyAuthStore():Promise<JWTStore> {
 return await verifyAuth("storeAuth") as unknown as JWTStore
}