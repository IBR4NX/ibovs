
import mongoose, {Types, Document} from 'mongoose';
import { type } from 'os';
//    Name
export interface IUser extends Document {
  _id: Types.ObjectId;
  name?: string;
  email?: string;
  password?: string;
  role?: string;
  status?: string;
  imgUrl?: string;
}
//    Name
const schema = new mongoose.Schema<IUser>(
  {   
    name: { type: String, required: [true," name is required"] },
    email: { type: String, required: [true," email is required"],
      match: [/^\S+@\S+\.\S+$/, "Invalid email address"],
      unique: true,lowercase: true,trim: true,
    },
    password: { type: String, required: [true," password is required"],select: false,
      minLength: [6, "Password must be at least 6 characters long"],
    },
    role: { type: String,select:true,
      enum:["user", "seller", "customer", "admin"] ,
      default: "user", 
    },
    status:{ type: String,select:true,
      enum:["active","pending","suspended","banned" ], default: "active"
    },
    imgUrl:{type: String,default:"/favicons/favicon.ico"},
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'createdAt' },
  }
);

schema.index({ _id: 1,email: 1, status: 1 });

export const userModel = mongoose.models.User || mongoose.model("User", schema); // 3  4
export default { schema,model:userModel} 
