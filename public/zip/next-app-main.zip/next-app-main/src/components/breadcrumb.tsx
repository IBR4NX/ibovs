'use client'
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis
} from "@/components/ui/breadcrumb";
import { usePathname } from "next/navigation";
function BreadcrumbAhmed() {
  const pathName = usePathname();
  const location =  (""+pathName).split('/');
  let pName="";
  let lastItems=location.length-1;
  return (
    <>
      <Breadcrumb dir="rtl" className="bg-red-500 m-0 text-[10px]!">
        <BreadcrumbList>
        {/* <BreadcrumbEllipsis/> */}
        {location.map((item,i)=>{
          pName+="/"+item;
          // console.log(pName);
           return
            <div className="inline" key={item} >
              {i===location.length-1?
             <BreadcrumbItem key={item}>
                <BreadcrumbPage>{item}</BreadcrumbPage>
              </BreadcrumbItem> 
            :
              <BreadcrumbItem key={item} className=" md:block">
              <BreadcrumbLink href={pName} >{item}</BreadcrumbLink>
              </BreadcrumbItem>
              }
              {i!==location.length-1&&
                
            <BreadcrumbSeparator className=" md:block" /> 
              }
           </div>
          }
        )
      }
        
        </BreadcrumbList>
      </Breadcrumb>
    </>
  );
}

export default BreadcrumbAhmed;
