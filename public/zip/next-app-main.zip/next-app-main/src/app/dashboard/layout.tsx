'use client'
import { Separator } from "@/components/ui/separator";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
interface DashboardLayoutProps {
  children: React.ReactNode;
}
import { ModeToggle, ThemeToggle } from "@/components/theme-provider";
// import { SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { TooltipProvider } from "@/components/ui/tooltip";
import BreadcrumbAhmed from "@/components/breadcrumb";
import SideTrigger from "@/components/nav/side-trigger";
import * as React from "react"
import { AlertProvider } from "@/components/AlertProvider";
import Search from "@/components/command"
import { DynamicIcon } from "lucide-react/dynamic";
export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [loading ,setLoading]=React.useState(false);
  React.useEffect(() => {
    setLoading(true)
  }, [])
  if (!loading) {
    return null
  }
  console.log("DashboardLayout :");
  
  return (
    <>
      <TooltipProvider>
        <SidebarProvider>
          <AppSidebar />
          <SidebarInset>
            <header className='bg-background sticky top-0 flex shrink-0 items-center gap-2 border-b p-4'>
              {/* <SidebarTrigger className="-ml-1" /> */}
              <div className='flex fle items-center gap-2'>
                <SideTrigger />
                <Separator
                  orientation='vertical'
                  className='mr-2 data-[orientation=vertical]:h-4 h-full! '
                />
                {/* <ModeToggle/> */}
                <Separator
                  orientation='vertical'
                  className='mr-2 data-[orientation=vertical]:h-4 h-full! '
                />
                {/*   <div className=" absolute top-0 left-0 ">
                  
                <BreadcrumbAhmed />
                </div> 
                */}
              </div>
              <div className='mr-auto flex gap-1 items-center'>
                <ThemeToggle />
                <DynamicIcon
                  name='camera'
                  color='red'
                  size={24}
                  strokeWidth={2}
                />
                <Search/>
              </div>
            </header>
            <main>
          <AlertProvider>{children}</AlertProvider>
            </main>
          </SidebarInset>
        </SidebarProvider>
      </TooltipProvider>
    </>
  );
}
