// src@/controllers/user.controller.ts
"use server"
 import { createUser, findUserByEmail,
  findAllUsers,  findUserById,updateUser } from '@/repositories/user.repository'
import bcrypt from 'bcryptjs';
import { cookies } from "next/headers";
import {  setAuthUser , verifyRefreshToken} from '@/lib/auth';
import { redirect } from 'next/navigation';
import  {Types} from 'mongoose';
// GET /api/users
export async function getUsers() {
  const users = await findAllUsers();
  return (users);
}
// GET /api/users/:id
export async function getUser(id: string) {
  const user = await findUserById(id);
  if (!user) return 'User not found' ;
  return (user);
}


export async function signup(name:string,email:string, password:string) {
  const existingUser = await findUserByEmail(email);
  if (existingUser)throw new Error(' email of user already exists');
  
  const passwordHash = await bcrypt.hash(password, 10);
  console.log(passwordHash);
  const {error, user} = await createUser( name, email, passwordHash);
  
  if (error)throw new Error(error);
  console.log("Signup successful");
  return user
}
import getTest from "@/test"
export async function login(email:string, password:string) {
  //const existingUser = getTest.findUserTest();
 // console.log("findUserTest: ");
 // console.log(existingUser);
  const existingUser = await findUserByEmail(email);
  if (!existingUser)throw new Error(' email is not exists');
  const passwordMatch = await bcrypt.compare(password, existingUser.password.toString());
  if (!passwordMatch)throw new Error('Email or password not correct');
  
  console.log("Login successful",existingUser.id);
  return existingUser;
}

export async function logout() {
   const store =await cookies();

  const all = store.getAll();
  for (const cookie of all) {
    store.delete(cookie.name);
  }
  redirect('/')
}
export async function changeUserRole(id: string, role: "user" |"seller" | "admin" | "moderator") {
  if (!Types.ObjectId.isValid(id)) throw new Error("Invalid userId");
  return await updateUser(id,{role})
}
export async function refreshAuth() {
  const session = await verifyRefreshToken()
  if (!session) {return   }
  if (session.store)await setAuthStore(session.store)
   await setAuthUser(result);
}