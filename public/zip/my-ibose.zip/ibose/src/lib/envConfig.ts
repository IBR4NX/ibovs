import { loadEnvConfig } from '@next/env'
 
const projectDir = process.cwd()
loadEnvConfig(projectDir)

 const environment=process.env.NODE_ENV;
 const PORT=process.env.PORT;
 const DB_URL=process.env.DATABASE_URL;
 const corsUrl = process.env.CORS_URL;
 const SECRET=process.env.SECRET;
 const JWT_ACCESS_SECRET=process.env.JWT_ACCESS_SECRET || "";
 const JWT_REFRESH_SECRET=process.env.JWT_REFRESH_SECRET || "";

 export const SESSION_SECRET=process.env.SESSION_SECRET || " "
// console.log(SESSION_SECRET)
export { environment, PORT, DB_URL, corsUrl, SECRET, JWT_ACCESS_SECRET, JWT_REFRESH_SECRET };

// const firebaseConfig = {
//   apiKey: process.env.FIREBASE_API_KEY,
//   authDomain: process.env.FIREBASE_AUTH_DOMAIN,
//   projectId: process.env.FIREBASE_PROJECT_ID,
//   storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
//   messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
//   appId: process.env.FIREBASE_APP_ID,
// }

import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);
