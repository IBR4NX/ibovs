import  {  UserModel, IUser} from "@/models/store.model";
import  {  StoreModel, IStore} from "@/models/store.model";
import { connectDB } from "@/lib/connectDB";
import Link from "next/link";

export default async function StoresPage() {
  await connectDB();

  const stores = await StoreModel.find().lean();
  const store = await StoreModel.findOne().lean();
  console.log(stores);
  store.id=store._id.toString()
  delete store._id
  console.log(store);
  return (
    <div>
      <h1>All Stores</h1>

      {stores.length === 0 && <p>No stores found</p>}

      <ul>
        {stores.map((store: any) => (
          <li key={store._id}>
            <Link href={`/stores/${store.slug}`}>
              {store.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}