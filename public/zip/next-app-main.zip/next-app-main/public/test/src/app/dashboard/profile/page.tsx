"use client";
import { useEffect, useState } from "react"; import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import TextInput  from "@/components/inputs/textInput";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field";
import StoreForm from '@/ui/storeForm'
export default function ProfilePage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => { 
    const file = e.target.files?.[0]; if (!file) return; 
    setSelectedImage(file);
    console.log(file);
    setImagePreview(URL.createObjectURL(file)); };

// useEffect(() => {
//     const token = localStorage.getItem("token");
//    const userInfo = JSON.parse(localStorage.getItem("user")||'{}');
//    setName(userInfo.name);
//    setEmail(userInfo.email);
//   }, [false]);
  const handleSubmit =async (e: React.FormEvent<HTMLFormElement>) => { 
    e.preventDefault();
    const formData = new FormData();
    
    formData.append("name",name);
    formData.append("email", email);
    console.log(formData);
    if(selectedImage)formData.append("avatar", selectedImage);

  };

  return (
    <div className="flex flex-col justify-center items-start min-h-screen bg-muted p-6">
      <Card className="w-full max-w-md"> 
        <CardHeader className="flex flex-col items-center gap-3">
        <CardTitle className="text-center text-xl">تعديل معلومات الحساب</CardTitle> 
          {/* <div > */}
        </CardHeader>
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit}>
            <FieldGroup>
          <Avatar className="w-24 h-24 m-auto">
            <Label htmlFor="avatar">
            <AvatarImage src={imagePreview ?? undefined} />
            </Label>
          <Input type="file" accept="image/*" id="avatar" className=" absolute size-full opacity-0 z-10 bg-red-500 rounded-full" onChange={handleImageChange} />
            <AvatarFallback>
              اضافة الصورة
            </AvatarFallback>
          </Avatar>
          {selectedImage&&
            
            <Button type="submit" className="w-full">حفظ التعديلات</Button>
          }
            </FieldGroup>
          </form>
        {/* </div> */}
    <StoreForm 
    defaultValues={getUserFromStorage()}/>
      </CardContent>
    </Card>
    </div >

  );
}

export function getUserFromStorage(){
  const data = localStorage.getItem("store");
  return data ? JSON.parse(data) : null;
}