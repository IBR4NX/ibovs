"use client"
import { NavMain } from "@/components/nav/nav-main"
import { NavProjects } from "@/components/nav/nav-projects"
import  {NavUser }  from "@/components/nav/nav-user"
import { TeamSwitcher } from "@/components/nav/nav-switcher"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarRail,
} from "@/components/ui/sidebar"
import { useEffect,useState,ComponentProps } from "react"

import { navMain, storeData, data } from '@/components/nav/data'
// This is sample data.


 import { SidebarOptInForm } from "./nav/sidebar-opt-in-form"
import { Separator } from "./ui"
import { SearchForm } from "./form/search-form"
import useSWR from "swr";
export function AppSidebar({ ...props }: ComponentProps<typeof Sidebar>) {
  const { data:user} = useSWR("/user");
  const { data:stores} = useSWR("/store");
  const [loading ,setLoading]=useState(false);
  useEffect(() => {
  setLoading(true)
  }, [])
  console.log("render");
  if(!loading)return null
  return (
    <Sidebar dir="rtl" side="right"  collapsible="icon" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          {/* 
          */}
         <TeamSwitcher stores={stores} defaultStore={stores[0]} /> 
        </SidebarMenu>
      </SidebarHeader>
        <Separator orientation="horizontal" />
      <SidebarContent>
        <NavMain items={navMain} />
        <NavProjects projects={data.projects} />
      </SidebarContent>
      <SidebarFooter>
        <Separator/>
        {/* <SidebarOptInForm/> */}
        <NavUser user={user}/>
         <SidebarOptInForm />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
