import { verifyToken, signToken, setAuthCookies, TokenConfig, IUser } from '@/lib/auth/authCookies';
import { cookies } from 'next/headers';

/**
 * checkAuth
 * يتحقق من access token الموجود في الكوكيز
 * @returns payload إذا التوكن صالح
 * @throws خطأ إذا غير صالح أو منتهي
 */
export async function checkAuth(): Promise<any> {
  const cookieStore = await cookies();
  const token = cookieStore.get('token')?.value;

  if (!token) throw new Error('Access token not found');

  const payload = await verifyToken(token, 'access');
  return payload;
}

/**
 * refreshToken
 * يستخدم refresh token لتجديد access token و refresh token
 * @param userData بيانات المستخدم لتجديد التوكنات
 * @param tokensConfig مصفوفة إعدادات التوكن (اختياري)
 */
export async function refreshToken(userData: IUser, tokensConfig: TokenConfig[] = undefined) {
  const cookieStore = await cookies();
  const refresh = cookieStore.get('refresh')?.value;

  if (!refresh) throw new Error('Refresh token not found');

  // تحقق من صلاحية refresh token
  const payload = await verifyToken(refresh, 'refresh');

  // تجديد التوكنات
  await setAuthCookies(userData, tokensConfig);

  return payload; // ترجع بيانات المستخدم القديمة (payload)
}