import { Schema, model, Types } from "mongoose";

const productSchema = new Schema(
  {
    store: {
      type: Types.ObjectId,
      ref: "Store",
      required: true,
    },

    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 150,
    },

    description: {
      type: String,
      maxlength: 1000,
    },

    price: {
      type: Number,
      required: true,
      min: 0,
    },

    stock: {
      type: Number,
      default: 0,
      min: 0,
    },

    images: [
      {
        type: String, // Firebase URLs
      },
    ],

    category: {
      type: String,
      index: true,
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

// تحسين الأداء
productSchema.index({ store: 1 });
productSchema.index({ name: "text" });

export const Product = model("Product", productSchema);