import { createStoreByOwner, findStoreByOwner } from "@/controller/store.controlle";
import { verifySession } from "@/lib/dal";
import { NextResponse } from "next/server";
export async function POST(req:Request) {
    const body = await req.json();
    const {owner,data}=body;
    const store= await createStoreByOwner(owner,data);
    return NextResponse.json(store);
}

export async function GET(req:Request) {
    // const body=await req.json();
    // const {owner,...data}=body;
    const session = await verifySession();
    const data= await findStoreByOwner(session.userId);
    console.log(data)
    return Response.json({
      user:{
        name:data.owner.name,
        email:data.owner.email,
        avatar:data.owner.avatar
      },
      store:{
        name:data.name,
        description:data.description,
        phone:data.phone,
        address:data.address,
        slug:data.slug,
        logo:data.logo
      }
    });
}