'use server'
import 'server-only'
import  {  StoreModel, IStore} from "@/models/store.model";
import  {  userModel, IUser} from "@/models/user.model";
import { createStore, findStoreByOwner,findStoreById,findAllStoreByOwner } from '@/repositories/store.repository'
import { verifyAuthStore,verifyAuthUser,setAuthStore } from '@/lib/auth';
import { findUserById } from '@/repositories/user.repository';
import { redirect } from "next/navigation";
export async function serialize<T>(data: T): T {
  return await JSON.parse(JSON.stringify(data));
}
//    create store by owner
  //const test =await store.collection.dropIndex("owner_1");
export async function checkSlug(slugCheck:any) {
  const slug = slugCheck.toLowerCase().trim();
  const slugExists = await StoreModel.exists({ slug });
  return slugExists
}
export async function register(data:IStore) {
  const slug = data.slug.toLowerCase().trim();
  const slugExists = await StoreModel.exists({ slug });
  if (slugExists) {
    throw new Error('Slug already exists plase modfiy slug ');
    }
  const storesCount = await StoreModel.countDocuments({ owner: data.owner });
  if (storesCount>=3) {
    await StoreModel.deleteMany({});
    throw new Error('Owner can only create up to 3 stores');
    }
   const {error,store} = await createStore(data)
   if(error)throw new Error('error schema:',error);
  return store
  }
export async function getAllStores() {
  const session = await verifyAuthStore();
  const store = await findStoreById(session.id)
  const stores = await findAllStoreByOwner(session.owner)
  const data= {store:await serialize(store),stores:await serialize(stores)}
  return data
}
export async function loginOwner() {
  const session = await verifyAuthUser();
  const store = await findStoreByOwner(session.id);
  const result = await setAuthStore(store);
  redirect("/dashboard");
}
export async function getStore(){
  const session = await verifyAuthStore();
  if (!session) {
   await loginOwner()
  }
  const store = await findStoreById(session.id)
  // const store=stores[0]
  console.log(store);
   return {
    store:{
      name:store.name,
      description:store.description,
      phone:store.phone,
      address:store.address,
      slug:store.slug,
      imgUrl:store.imgUrl
    },
    owner:{
      name:store.owner.name,
      email:store.owner.email,
      imgUrl:store.owner.imgUrl
    }
   }
}
