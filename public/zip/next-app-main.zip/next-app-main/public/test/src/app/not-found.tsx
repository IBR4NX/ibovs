import { Button } from "@/components/ui/button"
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty"
import { BellIcon } from "lucide-react"
import { RefreshCcwIcon } from "lucide-react"
import Link from "next/link"

export default function NotFound() {
  return (
    <Empty className="bg-muted/30 h-full">
      <EmptyHeader>
        <EmptyMedia variant="icon">
          <BellIcon />
        </EmptyMedia>
        <EmptyTitle>Page Not Found</EmptyTitle>
        <EmptyDescription className="max-w-xs text-pretty">
          You&apos;re all caught up. New notifications will appear here.
        </EmptyDescription>
      </EmptyHeader>
      <EmptyContent>
        <Button variant="outline"  >
          <Link href="/" className="flex">
          <RefreshCcwIcon />
          Go To Home
          </Link>
        </Button>
      </EmptyContent>
    </Empty>
  )
}
