import InteractiveHero from '@/ui/interactive-hero'
const StorePage =() => {

  return (
    <InteractiveHero/>  
  )
}

export default StorePage