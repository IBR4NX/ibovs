import { changeUserRole} from "@/controllers/user.controller";
import { verifyAuthStore, verifyAuthUser,setAuthStore,setAuthUser } from '@/lib/auth';
import { NextResponse } from "next/server"
import { redirect } from "next/navigation";
import { findStoreById ,createStore, findStoreByOwner } from '@/repositories/store.repository';
import {register } from '@/controllers/store.controller'
export async function POST(req:Request) {
    const session = await verifyAuthUser();
    const body = await req.json();
    const data={
    owner:session.id,
    name:body.name,
    slug:body.slug,
    description:body.description
    };
   // console.log(session);
    try {
    const store= await register(data)
    const user= await changeUserRole(session.id,"seller")
     console.log(store);
     console.log(user);
    await setAuthUser(user);
    await setAuthStore(store);
     console.log("@ssssssssss");
    } catch (err) {
     // console.error('Error:', err);
    return NextResponse.json({error:err.message},{status:400});
    }
  // return NextResponse.json({message:"ssssssssssssss"},{status:200});
  return NextResponse.redirect(new URL('/dashboard', req.url));
 
}


export async function GET(req:Request) {
    const store = await verifyAuthStore();
    const session = await verifyAuthUser();
    const data= await findStoreById(store?.id);
    //const data = dataStore[0]
    console.log(data)
    return Response.json({
      user:{
        name:data.owner.name,
        email:data.owner.email,
        avatar:data.owner.avatar
      },
      store:{
        name:data.name,
        description:data.description,
        phone:data.phone,
        address:data.address,
        slug:data.slug,
        logo:data.logo
      }
    });
}