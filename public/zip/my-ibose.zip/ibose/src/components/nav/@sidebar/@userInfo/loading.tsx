import { LoaderSkeleton } from "@/components/animations/skeleton";
const loading = () => {
  return (
    <div className="flex">
      <LoaderSkeleton width={35} height={35} borderRadius={100} />
      <div className="w-3/4">
        <LoaderSkeleton
          className="m-1"
          width={100}
          height={15}
          borderRadius={8}
        />
        <LoaderSkeleton height={15} />
      </div>
    </div>
  );
};

export default loading;
