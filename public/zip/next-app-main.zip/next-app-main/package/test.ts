import { FDO } from "./index";

const user = { name: "Ibrahim", age: 22, city: "Sana'a" };

// حالة مفاتيح موجودة فقط
const filtered1 = FDO(user, ["name", "city"]);
console.log(filtered1);
// ناتج: { name: 'Ibrahim', city: "Sana'a" }

// حالة مفتاح غير موجود
const filtered2 = FDO(user, ["name", "email"]);
console.log(filtered2);
// ناتج: { name: 'Ibrahim' }  (email تم تجاهله)
const obj = { name: "Ibrahim" };

const desc = Object.getOwnPropertyDescriptor(obj, "name");
console.log(desc);