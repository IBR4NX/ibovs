// import { createStore, findStoreByOwner,findStoreBySlug } from '@/repositories/store.repository'
'use server'
import  {Types} from 'mongoose';
import  {  storeModel, IStore} from "@/models/store.model";
import { connectDB } from "@/lib/connectDB";

export async function createStore(data:object) {
  await connectDB()
  const newStore= new storeModel(data);
  const error =  newStore.validateSync();
  if(error)return {error,store:null} 
  const store = await newStore.save()
  return {error:null, store}
}
// Bring a user by email : Promise<IUser | null>
export async function findStoreByOwner(owner: string) {
  await connectDB()
  const user = await storeModel.findOne({ owner: owner.toLowerCase() }).lean();
  return user
  //user.id=user._id.toString()
}
export async function findAllStoreByOwner(owner:string) {
  await connectDB()
  return await storeModel.find({owner}).lean();
  
}

export async function findStoreById(id:string) {
  await connectDB()
  const store= await storeModel.findById(id);
  return store
}
export async function  findStoreBySlug(slug:string) {
  await connectDB()
  return await storeModel.findOne({ slug });
 // const {name ,owner,location,description,...rest}= await storeModel.findById(store._id);
}
export async function updateStore(id:string,data:object) {
  await connectDB()
  return await storeModel.findByIdAndUpdate(id,data);
}