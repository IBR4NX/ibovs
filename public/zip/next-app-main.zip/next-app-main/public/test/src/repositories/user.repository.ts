// import { createUser, findUserByEmail } from '@/repositories/user.repository.ts'
'use server'
//import 'server-only'
import mongoose, {Types} from 'mongoose';
import userModel, { IUser } from '@/models/user.model';
import { connectDB } from "@/lib/connectDB";

export async function createUser(name:string,email:string, password:string) {
  await connectDB()
  const newUser = new userModel({name, email, password});
  const error = newUser.validateSync();
  console.log("user.service:41 :", newUser);
  if(error)return {error,user:null} 
  const user = await newUser.save()
  return {error:null, user}
}

// Bring a user by email : Promise<IUser | null>
export async function findUserByEmail(email: string) {
  await connectDB()
  const user = await userModel.findOne({ email: email.toLowerCase() }).lean();
  if(user)user.id=user._id.toString()
  return user
}

// جلب مستخدم واحد بالـ id
export async function findUserById(id: string): Promise<IUser | null> {
  await connectDB()
  if (!mongoose.Types.ObjectId.isValid(id)) return null;
  const user =await userModel.findById(id).lean();
  user.id=user._id.toString();
  return user
}
export async function updateUser(id:string,data:object) {
  await connectDB()
  console.log(data);
  return await userModel.findByIdAndUpdate(id,data,{ returnDocument: "after", runValidators: true });
}
// جلب جميع المستخدمين
export async function findAllUsers(): Promise<IUser[]> {
  await connectDB()
  return userModel.find().lean();
}
