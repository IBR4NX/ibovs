import { LoaderSkeleton } from "@/components/animations/skeleton";

export default function loading() {
  return (
    <>


        <div className=" pt-2  gap-6 flex flex-col ">
        <LoaderSkeleton height={30}  borderRadius={1000} />

        {Array.from({ length: 5 }).map((_, index) => (
          <LoaderSkeleton key={index} height={25} borderRadius={100} />
        ))}
        </div>

    </>
  );
}
