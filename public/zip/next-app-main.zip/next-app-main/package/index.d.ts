
export function sum(a: number, b: number): number;

export function capitalize(str: string): string;

export function FDO<T extends object>(
  data: T,
  keysToKeep: (keyof T | string)[]
): Partial<T>;
