"use server";

import { redirect } from "next/navigation";
import { connectDB } from "@/lib/connectDB";
import modelStore from "@/models/store";
import { getStoreAndProfile, verifySession } from "@/lib/dal";
import { uploadFile } from "@/lib/uploadSupabase";
import { revalidatePath } from "next/cache";
import { createSessionStore } from "@/lib/session/create";
import { createStoreByOwner, findStoreByOwner } from "@/controller/store.controlle";
import { Types } from "mongoose";

import userModel from '@/models/user.model';




export async function createStore(
  state: any,
  formData: FormData
) {
  await connectDB();
  console.log(" verifySession")
  const session = await verifySession();
  if(!session.userId)return
  // const update = await findStoreByOwner(session?.userId);
  // if (update) {
  //   return {
  //     success: false,
  //     message: "Store already exists"
  //   }
  // }
  // console.log(session)
  // owner: session?.userId as Types.ObjectId,
  const data = {
    name: formData.get("name") as string,
    description: formData.get("description") as string,
    phone: formData.get("phone") as string,
    location: formData.get("location") as string,
    slug: formData.get("slug") as string,
  };
  await connectDB();
  const {success,message,store}= await createStoreByOwner(session.userId ,data);

  const up = await userModel.findByIdAndUpdate(session?.userId, { role: "store" });
  await createSessionStore(store._id)
  if(!success){
    return {success,message}
  }
  console.log(success,message,store)
  return {success,message}

  // if (!validatedFields.success) {
  //   return {
  //     success: false,
  //     errors: validatedFields.error.flatten().fieldErrors,
  //   };
  // }
  // const store = await modelStore.findOne({});
  const storeExist = await modelStore.findOne({ owner: session?.userId });
  const user = await modelStore.findByIdAndUpdate(session?.userId, { role: "store" });
  if (storeExist) {
    const logo = await uploadFile(storeExist._id, formData.get('logo') as File)
    await modelStore.findByIdAndUpdate(storeExist._id, { logo: logo })
  } else {

    const store = await modelStore.create({ owner: session?.userId, logo: user?.avatar });
  }
  revalidatePath('/dashboard')
  redirect("/dashboard");
}



export async function myStore() {
  await connectDB();
  const data = await getStoreAndProfile();
  return data
}
