import { toast } from "sonner";

type ActionState = {
  success?: boolean;
  message?: string;
};
let id;
const messageLoading=<div className="flex justify-between w-full min-w-72">
    <span className="text-left">جارٍ معالجة البيانات...</span><span dir="ltr" className="text-right">Processing data...</span>
  </div>;
export default function actionToast(state?: ActionState,pending?:boolean) {
  if(!state&&!pending)return
  if (pending &&!id) {
    id= toast.loading(messageLoading,{position: "top-center" })
  return
  if (pending){toast.loading(messageLoading,{id})
  return}
  }else if (state) {
  toast.promise(
   new Promise((resolve, reject) => {
    setTimeout(() => {
      if (state?.success) resolve(state?.message ?? "The operation was successful. ");
      else reject(state?.message ?? "Error: The process was not completed.");
    }, 1000);
   }),
    {id,
      loading:messageLoading,
      success: state?.message,
      error: state?.message,
      position: "top-center",
      duration:5000,
      cancel: {
            label: 'Cancel',
            onClick: () => console.log('Cancel!'),
          }
    },
  
  );
  }
  return
}