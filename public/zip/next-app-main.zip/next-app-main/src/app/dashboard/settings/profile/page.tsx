"use client";

import { useEffect, useState } from "react";
import CardInfo from "@/ui/cardInfo"
type User = {
  name: string;
  email: string;
  imgUrl?: string;
  role?: string;
};
import convertData from '@/services/convertData'
import useSWR, {useSWRConfig} from "swr";
export default function AccountPage() {
  const { data} = useSWR("/store");
    const con = useSWRConfig()
  console.log(con);
  
  return (
    <div className="max-w-2xl mx-auto py-10 px-4">
      {data?
      <CardInfo data={convertData(data[0])} url="/store"/>
        : <p className="text-muted-foreground">No user data found.</p>
      }
    </div>
  );
}