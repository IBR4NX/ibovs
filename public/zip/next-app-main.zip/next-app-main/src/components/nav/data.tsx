
import {
  Store,
  Package,
  ShoppingCart,
  Users,
  MapPin,
  Bell,
  Settings,
  BarChart3,
} from "lucide-react";
import {
  AudioWaveform,
  BookOpen,
  Bot,
  Command,
  Frame,
  GalleryVerticalEnd,
  Map,
  PieChart,
  Settings2,
  SquareTerminal,
} from "lucide-react"

export const navMain = [
  {
    title: "لوحة التحكم",
    url: "/dashboard",
    icon: BarChart3,
    isActive: true,
    items: [
      {
        title: "نظرة عامة",
        url: "/dashboard",
      },
      {
        title: "الإحصائيات",
        url: "/dashboard/analytics",
      },
    ],
  },
  {
    title: "متجري",
    url: "/store",
    icon: Store,
    items: [
      {
        title: "عرض المتجر",
        url: "/store/view",
      },
      {
        title: "تخصيص المتجر",
        url: "/store/customize",
      },
    ],
  },
  {
    title: "المنتجات",
    url: "/products",
    icon: Package,
    items: [
      {
        title: "كل المنتجات",
        url: "/products",
      },
      {
        title: "إضافة منتج",
        url: "/products/new",
      },
    ],
  },
  {
    title: "الطلبات",
    url: "/orders",
    icon: ShoppingCart,
    items: [
      {
        title: "الطلبات الجديدة",
        url: "/orders?status=new",
      },
      {
        title: "الطلبات المكتملة",
        url: "/orders?status=completed",
      },
    ],
  },
  {
    title: "العملاء",
    url: "/customers",
    icon: Users,
    items: [
      {
        title: "قائمة العملاء",
        url: "/customers",
      },
    ],
  },
  {
    title: "الظهور الجغرافي",
    url: "/location",
    icon: MapPin,
    items: [
      {
        title: "إعداد الموقع",
        url: "/location",
      },
    ],
  },
  {
    title: "الإشعارات",
    url: "/notifications",
    icon: Bell,
    items: [
      {
        title: "كل الإشعارات",
        url: "/notifications",
      },
    ],
  },
  {
    title: "الإعدادات",
    url: "/settings",
    icon: Settings,
    items: [
      {
        title: "معلومات الحساب",
        url: "/settings/profile",
      },
      {
        title: "الأمان",
        url: "settings/security",
      },
    ],
  },
];

export const storeData={
     name:"",
     bio:"",
     phone:"",
     address:"",
     slug:"",
   imgUrl:""
}
export const data = {
  user: {
    name: ".....",
    email: "....@..",
    imgUrl: "",
  },
  teams: [
    {
      name: "Ibrahim Al-Mekhlafi",
      logo: GalleryVerticalEnd,
      plan: "Enterprise",
    },
    {
      name: "Acme Corp.",
      logo: AudioWaveform,
      plan: "Startup",
    },
    {
      name: "Evil Corp.",
      logo: Command,
      plan: "Free",
    },
  ],
 
  projects: [
    {
      name: "Design Engineering",
      url: "#",
      icon: Frame,
    },
    {
      name: "Sales & Marketing",
      url: "#",
      icon: PieChart,
    },
    {
      name: "Travel",
      url: "#",
      icon: Map,
    },
  ],
}