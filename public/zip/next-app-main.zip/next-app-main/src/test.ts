// import { createUser, findUserByEmail } from '@/repositories/user.repository.ts'
//'use server'
import 'server-only'
import mongoose, {Types} from 'mongoose';
import userModel, { IUser } from '@/models/user.model';
const userTest ={
  name: 'إبراهيم دبوان ناجي ',
  email: 'admin@gmail.com',
  role: 'user',
  isActive: true,
  status: 'active',
  password: '$2b$10$omgWVSg7ILbZGi7ZMhWBCeRUIZqNpPcuIvcvRQPvgmlwMBvs.U/tW',
  imgUrl: '/favicons/favicon.ico',
  _id: new Types.ObjectId('699798d7a8e2e3848ad59880')
}
userModel.const foundIndex = array.findIndex((item) => {
  return condition;
});

stores: [
    {
      _id: '699ce5400e8d93f7cbb95e90',                             
      owner: '699798d7a8e2e3848ad59880',                            
      name: 'إبراهيم دبوان',                                     
      slug: 'admin',                                                
      description: 'إبراهيم محمد بن سلمان بن عبدالعزيز بن ',     
      imgUrl: 'http://localhost:3000/favicons/favicon-96x96.png',        
      isActive: true,
      createdAt: '2026-02-23T23:39:44.792Z',                           
      updatedAt: '2026-02-23T23:39:44.792Z'                      
      },                                                                 
      {                                                                     
        _id: '699ce89f0e8d93f7cbb95ea8',   
        owner: '699798d7a8e2e3848ad59880', 
        name: 'إبراهيم دبوان',  
        slug: 'admijdjdjdhhh',    
        description: 'إبراهيم محمد بن سلمان بن عبدالعزيز بن ',
        imgUrl: 'http://localhost:3000/favicons/favicon-96x96.png',          
        isActive: true,                                                   
        createdAt: '2026-02-23T23:54:07.715Z',      
        updatedAt: '2026-02-23T23:54:07.715Z'         
        },                       
        {                               
          _id: '699cf9810e8d93f7cbb95f26',  
          owner: '699798d7a8e2e3848ad59880', 
          name: 'متجر الكتروني',                
          slug: 'mtjer',              
          description: 'متجرك الخاص بك هو منح البائع ',                 
          imgUrl: 'http://localhost:3000/favicons/favicon-96x96.png',      
          isActive: true,                                              
          createdAt: '2026-02-24T01:06:09.188Z',                         
          updatedAt: '2026-02-24T01:06:09.188Z'
    }
  ]

// Bring a user by email : Promise<IUser | null>

export function findUserTest() {
  const user=userTest
 // user.ikd=user._id.toString()
  return user
}
export function findStoresTest() {
  return //stores
}

export default { findUserTest ,findStoresTest }
//import getTest from "@/test"
