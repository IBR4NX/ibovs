"use client";

import * as React from "react";
import { ChevronsUpDown, Plus } from "lucide-react";
import {FieldGroup,FieldLabel} from "@/components/ui/field";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Form from "next/form";
import { Button, Input } from "../ui";
export function TeamSwitcher({
  store,
}: {
  store: {
    name?:string;
    description?:string;
    phone?:string;
    address?:string;
    slug?:string;
    logo?:string;

  };
}) {
  const { isMobile } = useSidebar();
  const [activeTeam, setActiveTeam] = React.useState(store);

  if (!activeTeam) {
    return null;
  }

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              size="lg"
              className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            >
              <Avatar>
                <AvatarImage src={store.logo } />
                <AvatarFallback>SH</AvatarFallback>
              </Avatar>
              <div className="grid flex-1 text-sm leading-tight">
                <span className="truncate font-medium">{store.name}</span>
                {/* <span className="truncate text-xs">{activeTeam.plan}</span> */}
              </div>
              {/* <ChevronsUpDown className="ml-auto" /> */}
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-(--radix-dropdown-menu-trigger-width) min-w-56 rounded-lg"
            align="start"
            side={isMobile ? "bottom" : "right"}
            sideOffset={4}
          >
            <Form action="/store" >
            <FieldGroup>
              <FieldLabel>Name</FieldLabel>
              <Input defaultValue={store.name} />
              <FieldLabel>Description</FieldLabel>
              <Input defaultValue={store.description} />
              <FieldLabel>Phone</FieldLabel>
              <Input defaultValue={store.phone} />
              <FieldLabel>Address</FieldLabel>
              <Input defaultValue={store.address} />
              <FieldLabel>Slug</FieldLabel>
              <Input defaultValue={store.slug} />
              <FieldLabel>Logo</FieldLabel>
              <Input type="file" defaultValue={store.logo} />
              <Button type="submit">Edit</Button>
            </FieldGroup>
            </Form>

           
            

          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
