import mongoose, { Schema, model, models } from "mongoose";
import modelStore from "../store";
const UserSchema = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true },
    password: { type: String, required: true },
    role: { type: String, default:"user" },
    status: { type: Boolean, default: true, select: false},
  },
  { timestamps: true }
);
UserSchema.pre('save', async function (next: any) {
  if (this.role === 'store') {
    const store = await modelStore.findOne({ owner: this._id  });
    if (!store) {
      await modelStore.create({ owner: this._id  });
    }
  }
  next();
});
UserSchema.pre(/^find/, function (next: any) {
  this.$where({status:true});
  next();
});
UserSchema.pre(/^find/, function (next: any) {
  if (!this.getQuery().showInactive) {
    this.where({ isActive: true });
  }
  next();
});


export const User = models.User || model("User", UserSchema);