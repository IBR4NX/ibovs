"use client";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Field,
  FieldError,
  FieldGroup,
  FieldLabel,
} from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import Form from "next/form";
import { useActionState } from "react";
import { createStore } from "@/app/action/store";

export default function CreateStoreForm() {
  const [state, action, pending] = useActionState(createStore, undefined);
  const error = state?.message;
  console.log(state)

  return (
    <Card>
      <CardHeader>
        <CardTitle>إضافة متجر</CardTitle>
        <CardDescription>
          أدخل بيانات المتجر لإنشائه
        </CardDescription>
      </CardHeader>

        <CardContent>
      <Form action={action}>
          <FieldGroup>
            <Field className="flex flex-col gap-2" >
              <FieldLabel htmlFor="name">اسم المتجر</FieldLabel>
              <Input
                id="name"
                name="name"
                placeholder="اسم المتجر"
                disabled={pending}
              />
              {/* <FieldError>{error?.name}</FieldError> */}
            </Field>
            {/* slug */}
            <Field>
              <FieldLabel htmlFor="slug">الرابط</FieldLabel>
              <Input
                id="slug"
                name="slug"
                placeholder="store-slug"
                disabled={pending}
                required
              />
              {/* <FieldError>{error?.slug}</FieldError> */}
            </Field>

            <Field>
              <FieldLabel htmlFor="description">الوصف</FieldLabel>
              <Input
                id="description"
                name="description"
                placeholder="وصف المتجر"
                disabled={pending}
                required
              />
              {/* <FieldError>{error?.description}</FieldError> */}
            </Field>

            <Field>
              <FieldLabel htmlFor="phone">رقم الهاتف</FieldLabel>
              <Input
                id="phone"
                name="phone"
                placeholder="رقم الهاتف"
                disabled={pending}
                required
              />
              {/* <FieldError>{error?.phone}</FieldError> */}
            </Field>

            <Field>
              <FieldLabel htmlFor="location">العنوان</FieldLabel>
              <Input
                id="location"
                name="location"
                placeholder="العنوان"
                disabled={pending}
                required
              />
              {/* <FieldError>{error?.address}</FieldError> */}
            </Field>
            <Field>
              <FieldLabel htmlFor="logo">الشعار</FieldLabel>
              <Input
                id="logo"
                name="logo"
                type="file"
                disabled={pending}
              />
            </Field>

            {state?.message  && (
               <FieldError>{state?.message}</FieldError> 
             )} 

            <Button disabled={pending} type="submit" className="mt-4 w-full">
              {pending ? "جاري الإنشاء..." : "إنشاء المتجر"}
            </Button>
          </FieldGroup>
      </Form>
        </CardContent>
    </Card>
  );
}