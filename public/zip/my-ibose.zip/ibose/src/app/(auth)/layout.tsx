import { CardSlideIn } from "@/components/animations/slide-in";
export default function AuthLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <>
      <div className=" min-h-svh w-full items-center justify-center p-6 md:p-10">
        <div className="w-full m-auto max-w-sm">
          <CardSlideIn direction="up">
            {children}
          </CardSlideIn>
        </div>
      </div>
    </>
  );
}
