import React from 'react'
import SidebarPage from './page'

function Default() {
  return null
}

export default Default
