
export async function POST(req:Request) {
    const body = await req.formData();
    // const { name } = body;
    console.log(body.get('img'))
    return new Response(body,{status:200});
}
export async function GET(req: Request,) {
    const body = await req.json();
    const { name } = body;
    console.log(body)
    return Response.json({ name });
}