// 'use client'
import { Separator } from "@/components/ui/separator";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
interface DashboardLayoutProps {
  children: React.ReactNode;
  dialog?: React.ReactNode;
}
import { ModeToggle, ThemeToggle } from "@/components/theme-provider";
// import { SidebarTrigger } from "@/components/ui/sidebar";
import  AppSidebar  from "@/components/app-sidebar";
import { TooltipProvider } from "@/components/ui/tooltip";
import BreadcrumbAhmed from "@/components/breadcrumb";
import { SearchForm } from "@/components/custom/search-form";
import SideTrigger from "@/components/nav/side-trigger";
export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <>
      <TooltipProvider>
        <SidebarProvider>
          {/* {sidebar} */}

          <AppSidebar />
          <SidebarInset>
            <header className="bg-background sticky top-0 flex shrink-0 items-center gap-2 border-b p-4">
              {/* <SidebarTrigger className="-ml-1" /> */}
              <div className="flex fle items-center gap-2">
                <SideTrigger />
                <Separator
                  orientation="vertical"
                  className="mr-2 data-[orientation=vertical]:h-4 h-full! "
                />
                <ThemeToggle />
                {/* <ModeToggle/> */}
                <Separator
                  orientation="vertical"
                  className="mr-2 data-[orientation=vertical]:h-4 h-full! "
                />

                <BreadcrumbAhmed />
              </div>
              <div className="mr-auto">
                <SearchForm />
              </div>
            </header>
            <main>{children}</main>
          </SidebarInset>
        </SidebarProvider>
      </TooltipProvider>
    </>
  );
}
