"use server"
//import 'server-only'
import { JWT_REFRESH_SECRET, JWT_SECRET, NODE_ENV } from '@/lib/envConfig'
import {JWTUser ,JWTStore, JWTPayload} from './types'
import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { IUser } from '@/models/user.model';
import { IStore } from '@/models/store.model'
const encodedKeyRefresh = new TextEncoder().encode(JWT_REFRESH_SECRET)
const encodedKey = new TextEncoder().encode(JWT_SECRET)
const tokens = ["token", "refresh"] as const;
type TokenType = 'token' | 'refresh';

export async function signToken(  payload: Record<string, any>,Ttype: TokenType):Promise<string> {
  console.log(`16- SignJWT =${Ttype}: `,payload);
  const key = Ttype === 'refresh' ? encodedKeyRefresh : encodedKey;
  const { expiresAt,type ,...restPayload } = payload;
  console.log(expiresAt," ~~~ ",type);
  const jwt = await  new SignJWT({...payload})
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(Math.floor((expiresAt?.getTime() || Date.now() + 10 * 60 * 1000) / 1000))
    .sign(key);
  return jwt
}
/**
 * verifyToken
 * @param token JWT string
 * @param type 'token' | 'refresh'
 * @returns payload إذا صالح
 * @throws خطأ إذا التوكن غير صالح أو منتهي
 */
// Verify Tokens
export async function verifyToken(token: string,type: TokenType ): Promise<JWTPayload | null> {
  const key = type === 'refresh' ? encodedKeyRefresh : encodedKey;
  try {
    const { payload } = await jwtVerify(token, key);
    return payload; // as unknown as JWTPayload
  } catch (err) {
    throw new Error('Invalid or expired token');
    return null as any
  }
}


//import { signToken, verifyRefreshToken } from '@/lib/jwt'
// Set auth cookies
export async function setAuth(data: IUser) {
  const filterData: any = { id: data.id ?? data._id.toString(), role: data.role };
  // إذا كانت storeId مصفوفة وليست فارغة، خزن أول متجر فقط
  if (Array.isArray(data.storeId) && data.storeId.length > 0) {
    filterData.storeId = data.storeId[0].toString();
  }
  const cookieStore = await cookies();
  for (const typeToken of tokens) {
    const maxAgeSeconds = typeToken === "token" ? 10 * 60 : 7 * 24 * 60 * 60;
    const expiresAt = new Date(Date.now() + maxAgeSeconds * 1000);
    const token = await signToken({ ...filterData, type: typeToken, expiresAt },typeToken);
    cookieStore.set(typeToken, token, {
      httpOnly: true,
      secure: NODE_ENV === "production",
      sameSite: "lax",
      maxAge: maxAgeSeconds,
      path: "/",
    });
  }
}

// Clear auth cookies
export async function clearAuthCookies() {
  const cookieStore = await cookies();
  cookieStore.delete('token');
  cookieStore.delete('refreshToken');
}
