// src/services/user.service.ts
'use server'
import mongoose, {Types} from 'mongoose';
import userModel, { IUser } from '@/models/user.model';
import { connectDB } from "@/lib/connectDB";
// جلب كل المستخدمين
export async function findAllUsers(): Promise<IUser[]> {
  await connectDB()
  return userModel.find().lean();
}
// جلب مستخدم واحد بالـ id


// Bring a user by email
export async function findUserByEmail(email: string): Promise<IUser | null> {
  await connectDB()
  if (!email) return null;
  return userModel.findOne({ email: email.toLowerCase() }).lean();
}

// إنشاء مستخدم جديد
export async function createNewUser(data: Partial<IUser>): Promise<IUser> {
  await connectDB()
  const user =await userModel.create(data);
  user.id=user._id.toString();
  console.log("createNewUser :");
  console.log(user.id);
  return user
}

// تحديث مستخدم
export async function updateUserById(id: string, data: Partial<IUser>): Promise<IUser | null> {
  await connectDB()
  if (!mongoose.Types.ObjectId.isValid(id)) return null;
  return userModel.findByIdAndUpdate(id, data, { new: true });
}

// حذف مستخدم
export async function deleteUserById(id: string): Promise<IUser | null> {
  if (!mongoose.Types.ObjectId.isValid(id)) return null;
  return userModel.findByIdAndDelete(id);
}

// تبديل حالة التفعيل
export async function toggleUserActiveById(id: string): Promise<IUser | null> {
  if (!mongoose.Types.ObjectId.isValid(id)) return null;
  const user = await userModel.findById(id);
  if (!user) return null;
  user.isActive = !user.isActive;
  await user.save();
  return user;
}
export async function changeUserRole(id: string, role: "user" |"seller" | "admin" | "moderator") {
  if (!Types.ObjectId.isValid(id)) throw new Error("Invalid userId");

  return await userModel.findByIdAndUpdate(
    id,
    { role },
    { returnDocument: "after", runValidators: true }
  );
}
//export default {findAllUsers,findUserById,findUserByEmail}