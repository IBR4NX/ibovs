"use client";
import * as React from "react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
import { MonitorCog, Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function ThemeProvider({
  children,
  ...props
}: React.ComponentProps<typeof NextThemesProvider>) {
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>;
}

export function ThemeToggle() {
  const { setTheme, themes } = useTheme();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon">
          <Sun className="h-[1.2rem] w-[1.2rem] scale-100 rotate-0 transition-all dark:scale-0 dark:-rotate-90" />
          <Moon className="absolute h-[1.2rem] w-[1.2rem] scale-0 rotate-90 transition-all dark:scale-100 dark:rotate-0" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {themes.map((theme) => (
          <DropdownMenuItem key={theme} onClick={() => setTheme(theme)}>
            {theme}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export const ModeToggle = () => {
  const { setTheme, themes,theme } = useTheme();
  // const index = themes.indexOf(theme||"li")
  // console.log(themes[index+1])
  const handleToggle = () => {
    const currentTheme = themes.indexOf(theme||"light");
    const nextTheme = (currentTheme+1) % themes.length;
    console.log(nextTheme)
    setTheme(themes[nextTheme]);
    
  }

  return (
    <div>
      <Button onClick={handleToggle} variant="secondary" size="icon" >
        {theme==="system"?<MonitorCog/>:theme === "dark" ? <Sun /> : <Moon />}
      </Button>
    </div>
  );
};
