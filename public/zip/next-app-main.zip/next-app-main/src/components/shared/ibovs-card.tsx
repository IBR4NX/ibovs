import { cn } from '@/lib/utils';
import { ReactNode, ComponentPropsWithoutRef, forwardRef } from 'react';
import * as Ibovs from "@/components/ui/card"
type IbovsCardProps = ComponentPropsWithoutRef<typeof Ibovs.Card> & {
	title?: ReactNode;
	description?: ReactNode;
	action?: ReactNode;
	footer?: ReactNode;
	children?: ReactNode;
	headerClassName?: string;
	contentClassName?: string;
	footerClassName?: string;
};
export const IbovsCard = forwardRef<HTMLDivElement, IbovsCardProps>(
	(
		{
			title,
			description,
			action,
			footer,
			children,
			className,
			headerClassName,
			contentClassName,
			footerClassName,
			...props
		},
		ref
	) => {
		return (
			<Ibovs.Card   ref={ref} className={cn(className,"m-2")} {...props}>
				{(title || description || action) && (
					<Ibovs.CardHeader className={cn(headerClassName)}>
						{title && <Ibovs.CardTitle>{title}</Ibovs.CardTitle>}
						{description && <Ibovs.CardDescription>{description}</Ibovs.CardDescription>}
						{action && <Ibovs.CardAction>{action}</Ibovs.CardAction>}
					</Ibovs.CardHeader>
				)}
				{children && <Ibovs.CardContent className={cn(contentClassName)}>{children}</Ibovs.CardContent>}

				{footer && <Ibovs.CardFooter className={cn(footerClassName,"lex gap-4 *:min-w-32 *:py-4")}>{footer}</Ibovs.CardFooter>}
			</Ibovs.Card>
		);
	}
);

IbovsCard.displayName = 'IbovsCard';

export default IbovsCard;