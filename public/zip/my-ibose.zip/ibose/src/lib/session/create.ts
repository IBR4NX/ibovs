
import { cookies } from "next/headers"
import { encrypt } from "@/lib/session/crypt"
export async function createSession(userId: string,role:string) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  const session = await encrypt({ userId,role, expiresAt })
  const cookieStore = await cookies()

  cookieStore.set('session', session, {
    httpOnly: true,
    secure: true,
    expires: expiresAt,
    sameSite: 'lax',
    path: '/',
  })
}
export async function createSessionStore(userId: string) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  const sessionStore = await encrypt({ userId, expiresAt })
  const cookieStore = await cookies()

  cookieStore.set('sessionStore', sessionStore, {
    httpOnly: true,
    secure: true,
    expires: expiresAt,
    sameSite: 'lax',
    path: '/',
  })
}