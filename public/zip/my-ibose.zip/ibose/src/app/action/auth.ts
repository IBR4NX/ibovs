'use server'
// import 'server-only'
import { SignupFormSchema, FormState } from '@/lib/definitions'
import { createSession, deleteSession } from '@/lib/session';
import { redirect } from 'next/navigation';
import { NextResponse } from 'next/server';
import userModel from '@/models/user.model';
import { connectDB } from "@/lib/connectDB";
import bcrypt from 'bcrypt';
import { em } from 'framer-motion/client';
import console from 'console';
import { findStoreByOwner } from '@/controller/store.controlle';

export async function signup(state: FormState, formData: FormData): Promise<FormState> {
  // Validate form fields
  const validatedFields = SignupFormSchema.safeParse({
    name: formData.get('name'),
    email: formData.get('email'),
    password: formData.get('password'),
  })
  if (!validatedFields.success) {
    return { success: false, errors: validatedFields.error.flatten().fieldErrors }
  }
  if (validatedFields.data.email) {
    const user = await userModel.findOne({ email: validatedFields.data.email });
    if (user) {
      return { success: false, message: "User already exists" }
    }
  }
  try {
    await connectDB();
    const { name, email, password } = validatedFields.data;
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await userModel.create({ name, email, password: passwordHash });
    if (!user) {
      return { message: "User created successfully" }
    }
    await createSession(user._id.toString(),user.role);
  } catch (error) {
    console.log(error)
    return { message: "User already exists" }
  }
  // return
  redirect('/')
}


export async function login(state: FormState, FromData: FormData): Promise<FormState> {
  const password = FromData.get('password');
  const email = FromData.get('email');
  // await new Promise((resolve, reject) => {
  //   setTimeout(() => {
  //     resolve(true);
  //   }, 1000);
  // })
    try {
      await connectDB();
      const user = await userModel.findOne({ email: email, isActive: true  }).select('+password');
      console.log(user)
      if (!user) {
      return { success: false, message: "User not found" }
    }
    if (!user.password || !user._id) return { success: false, message: "User not found" }
    const passwordMatch = await bcrypt.compare(password as string, user.password.toString());
    if (!passwordMatch) {
      return { success: false, message: "Email or password not correct" }
    }
    await createSession(user._id.toString(),user.role);
    // const store=await findStoreByOwner(user._id);
    // console.log(store)
    return { success: true, message: "User logged in successfully" }
    // redirect('/')
  } catch (error) {
    return { success: false, message: "User slss " }
  }
}

export async function logout() {
  await deleteSession()
  redirect('/')
}
